package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class Acinetobactor {
    @FXML
    private  TextField txtAcinetobactorBHRN,txtAcinetobactorNo;


    @FXML
    private ComboBox cmbAcinetobactorcc,cmbAcinetobactor1,cmbAcinetobactor2,cmbAcinetobactor3,cmbAcinetobactor4,cmbAcinetobactor5,cmbAcinetobactor6,cmbAcinetobactor7,cmbAcinetobactor8,cmbAcinetobactor9,cmbAcinetobactor10,cmbAcinetobactor11,cmbAcinetobactor12,cmbAcinetobactor13,cmbAcinetobactor14,cmbAcinetobactor15,cmbAcinetobactor16;

    @FXML
    public void initialize()
    {
        cmbAcinetobactorcc.getItems().removeAll(cmbAcinetobactorcc.getItems());
        cmbAcinetobactorcc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbAcinetobactor1.getItems().removeAll(cmbAcinetobactor1.getItems());
        cmbAcinetobactor1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor2.getItems().removeAll(cmbAcinetobactor2.getItems());
        cmbAcinetobactor2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor3.getItems().removeAll(cmbAcinetobactor3.getItems());
        cmbAcinetobactor3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor4.getItems().removeAll(cmbAcinetobactor4.getItems());
        cmbAcinetobactor4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor5.getItems().removeAll(cmbAcinetobactor5.getItems());
        cmbAcinetobactor5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor6.getItems().removeAll(cmbAcinetobactor6.getItems());
        cmbAcinetobactor6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor7.getItems().removeAll(cmbAcinetobactor7.getItems());
        cmbAcinetobactor7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor8.getItems().removeAll(cmbAcinetobactor8.getItems());
        cmbAcinetobactor8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor9.getItems().removeAll(cmbAcinetobactor9.getItems());
        cmbAcinetobactor9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor10.getItems().removeAll(cmbAcinetobactor10.getItems());
        cmbAcinetobactor10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor11.getItems().removeAll(cmbAcinetobactor11.getItems());
        cmbAcinetobactor11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor12.getItems().removeAll(cmbAcinetobactor12.getItems());
        cmbAcinetobactor12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbAcinetobactor13.getItems().removeAll(cmbAcinetobactor13.getItems());
        cmbAcinetobactor13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbAcinetobactor14.getItems().removeAll(cmbAcinetobactor14.getItems());
        cmbAcinetobactor14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbAcinetobactor15.getItems().removeAll(cmbAcinetobactor15.getItems());
        cmbAcinetobactor15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbAcinetobactor16.getItems().removeAll(cmbAcinetobactor16.getItems());
        cmbAcinetobactor16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void Acinetobactor() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtAcinetobactorBHRN.getText());

        recordData.add(txtAcinetobactorNo.getText());

    }
}
