package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class Citrobactor {
    @FXML
    private  TextField txtCitrobactorBHRN,txtCitrobactorNo;


    @FXML
    private ComboBox cmbCitrobactorcc,cmbCitrobactor1,cmbCitrobactor2,cmbCitrobactor3,cmbCitrobactor4,cmbCitrobactor5,cmbCitrobactor6,cmbCitrobactor7,cmbCitrobactor8,cmbCitrobactor9,cmbCitrobactor10,cmbCitrobactor11,cmbCitrobactor12,cmbCitrobactor13,cmbCitrobactor14,cmbCitrobactor15,cmbCitrobactor16;

    @FXML
    public void initialize()
    {
        cmbCitrobactorcc.getItems().removeAll(cmbCitrobactorcc.getItems());
        cmbCitrobactorcc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbCitrobactor1.getItems().removeAll(cmbCitrobactor1.getItems());
        cmbCitrobactor1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor2.getItems().removeAll(cmbCitrobactor2.getItems());
        cmbCitrobactor2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor3.getItems().removeAll(cmbCitrobactor3.getItems());
        cmbCitrobactor3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor4.getItems().removeAll(cmbCitrobactor4.getItems());
        cmbCitrobactor4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor5.getItems().removeAll(cmbCitrobactor5.getItems());
        cmbCitrobactor5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor6.getItems().removeAll(cmbCitrobactor6.getItems());
        cmbCitrobactor6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor7.getItems().removeAll(cmbCitrobactor7.getItems());
        cmbCitrobactor7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor8.getItems().removeAll(cmbCitrobactor8.getItems());
        cmbCitrobactor8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor9.getItems().removeAll(cmbCitrobactor9.getItems());
        cmbCitrobactor9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor10.getItems().removeAll(cmbCitrobactor10.getItems());
        cmbCitrobactor10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor11.getItems().removeAll(cmbCitrobactor11.getItems());
        cmbCitrobactor11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor12.getItems().removeAll(cmbCitrobactor12.getItems());
        cmbCitrobactor12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbCitrobactor13.getItems().removeAll(cmbCitrobactor13.getItems());
        cmbCitrobactor13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbCitrobactor14.getItems().removeAll(cmbCitrobactor14.getItems());
        cmbCitrobactor14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbCitrobactor15.getItems().removeAll(cmbCitrobactor15.getItems());
        cmbCitrobactor15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbCitrobactor16.getItems().removeAll(cmbCitrobactor16.getItems());
        cmbCitrobactor16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void Citrobactor() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtCitrobactorBHRN.getText());

        recordData.add(txtCitrobactorNo.getText());

    }
}
