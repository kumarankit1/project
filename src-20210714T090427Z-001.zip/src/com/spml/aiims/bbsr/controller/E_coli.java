package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class E_coli {
    @FXML
    private  TextField txtEcoliBHRN,txtEcoliNo;


    @FXML
    private ComboBox cmbEcolicc,cmbEcoli1,cmbEcoli2,cmbEcoli3,cmbEcoli4,cmbEcoli5,cmbEcoli6,cmbEcoli7,cmbEcoli8,cmbEcoli9,cmbEcoli10,cmbEcoli11,cmbEcoli12,cmbEcoli13,cmbEcoli14,cmbEcoli15,cmbEcoli16;

    @FXML
    public void initialize()
    {
        cmbEcolicc.getItems().removeAll(cmbEcolicc.getItems());
        cmbEcolicc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbEcoli1.getItems().removeAll(cmbEcoli1.getItems());
        cmbEcoli1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli2.getItems().removeAll(cmbEcoli2.getItems());
        cmbEcoli2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli3.getItems().removeAll(cmbEcoli3.getItems());
        cmbEcoli3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli4.getItems().removeAll(cmbEcoli4.getItems());
        cmbEcoli4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli5.getItems().removeAll(cmbEcoli5.getItems());
        cmbEcoli5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli6.getItems().removeAll(cmbEcoli6.getItems());
        cmbEcoli6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli7.getItems().removeAll(cmbEcoli7.getItems());
        cmbEcoli7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli8.getItems().removeAll(cmbEcoli8.getItems());
        cmbEcoli8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli9.getItems().removeAll(cmbEcoli9.getItems());
        cmbEcoli9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli10.getItems().removeAll(cmbEcoli10.getItems());
        cmbEcoli10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli11.getItems().removeAll(cmbEcoli11.getItems());
        cmbEcoli11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli12.getItems().removeAll(cmbEcoli12.getItems());
        cmbEcoli12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEcoli13.getItems().removeAll(cmbEcoli13.getItems());
        cmbEcoli13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbEcoli14.getItems().removeAll(cmbEcoli14.getItems());
        cmbEcoli14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbEcoli15.getItems().removeAll(cmbEcoli15.getItems());
        cmbEcoli15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbEcoli16.getItems().removeAll(cmbEcoli16.getItems());
        cmbEcoli16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void E_coli() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtEcoliBHRN.getText());

        recordData.add(txtEcoliNo.getText());

    }
}
