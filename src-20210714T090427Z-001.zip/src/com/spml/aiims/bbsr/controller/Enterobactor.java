package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class Enterobactor {
    @FXML
    private  TextField txtEnterobactorBHRN,txtEnterobactorNo;


    @FXML
    private ComboBox cmbEnterobactorcc,cmbEnterobactor1,cmbEnterobactor2,cmbEnterobactor3,cmbEnterobactor4,cmbEnterobactor5,cmbEnterobactor6,cmbEnterobactor7,cmbEnterobactor8,cmbEnterobactor9,cmbEnterobactor10,cmbEnterobactor11,cmbEnterobactor12,cmbEnterobactor13,cmbEnterobactor14,cmbEnterobactor15,cmbEnterobactor16;

    @FXML
    public void initialize()
    {
        cmbEnterobactorcc.getItems().removeAll(cmbEnterobactorcc.getItems());
        cmbEnterobactorcc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbEnterobactor1.getItems().removeAll(cmbEnterobactor1.getItems());
        cmbEnterobactor1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor2.getItems().removeAll(cmbEnterobactor2.getItems());
        cmbEnterobactor2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor3.getItems().removeAll(cmbEnterobactor3.getItems());
        cmbEnterobactor3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor4.getItems().removeAll(cmbEnterobactor4.getItems());
        cmbEnterobactor4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor5.getItems().removeAll(cmbEnterobactor5.getItems());
        cmbEnterobactor5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor6.getItems().removeAll(cmbEnterobactor6.getItems());
        cmbEnterobactor6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor7.getItems().removeAll(cmbEnterobactor7.getItems());
        cmbEnterobactor7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor8.getItems().removeAll(cmbEnterobactor8.getItems());
        cmbEnterobactor8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor9.getItems().removeAll(cmbEnterobactor9.getItems());
        cmbEnterobactor9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor10.getItems().removeAll(cmbEnterobactor10.getItems());
        cmbEnterobactor10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor11.getItems().removeAll(cmbEnterobactor11.getItems());
        cmbEnterobactor11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor12.getItems().removeAll(cmbEnterobactor12.getItems());
        cmbEnterobactor12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbEnterobactor13.getItems().removeAll(cmbEnterobactor13.getItems());
        cmbEnterobactor13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbEnterobactor14.getItems().removeAll(cmbEnterobactor14.getItems());
        cmbEnterobactor14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbEnterobactor15.getItems().removeAll(cmbEnterobactor15.getItems());
        cmbEnterobactor15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbEnterobactor16.getItems().removeAll(cmbEnterobactor16.getItems());
        cmbEnterobactor16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void Enterobactor() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtEnterobactorBHRN.getText());

        recordData.add(txtEnterobactorNo.getText());

    }
}
