package com.spml.aiims.bbsr.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class ExtraMuralHelper {
    public void saveRecord(ArrayList<String> data) {

        System.out.println(data.get(0));
        System.out.println(data.get(1));
    }

    public void insertDatabase(ArrayList<String> data) {
        try {
            String query = "insert into extramuraladmissions(entryid  ,CenterCode  , Highriskbaby  , Readmission  , Sex  , Modeofdelivery  , Babyattendedatbirthby  , SingleMultiple  , Motherbloodgroup  , Babybloodgroup  , Hearingscreening  , Leftear  , Rightear  , RedReflex  , Unit  , PreviousIUGR  , Antenatalcare  , Booked  , Atdischarge  , ROP  , Outcome  , MaternalDeath  , Hospitalcourse  , Intrauterinegrowthcategory  , BabyHospitalRecordno  , Mothername  , Dateofbirth  , Timeofbirth  , Birthweight  , Gestation  , Apgar1min  , Apgar5min  , Apgar10min  , Fathername  , Telnumber  , Mothercrno  , Maternalage  , Gravida  , Para  , Abortion  , Stillbirth  , OthersObsterticproblems , OthersRespiratorydistress  ,OthersCNSdisorders  , OthersMedicalProblems , Othersmajormalformations  , OthersMisc_morbidity  , Durationoxygen  , DurationCPAP  , DurationIMV  , Dateofdischarge , Weightatdischarge  , Headcircumference  , Dataenteredby  , Supervisedby  , Icterusatdischarge  , NNPDnumber  , Address  , Diagonsis  , Non_vertexpresentation  , Oxytocinuse  , ProlongedROM18h  , Meconiumstainedliquor  , Foulamellingliquor  , Fetalbradycardia120  , Fetaltachycardia160 , SevereanemiaHb7gdl  , Pregnancyinducedhypertension  , Preeclamptictoxemia  , Eclampsia  , Gestationaldiabetes  , Oligohydraminos  , Polyhydraminos  , Cephalopelvicdisproportion  , Previouscaesereandelivery  , Antepartumhemorrhage  , Placentaprevia  , Abruptioplacentae  , Transienttachypneadelayedadapt  , pneumonia  , meconiumaspiration  , hyalinemembranedisease  , pneumothorax  , oxygenresuscitation  , bagandmask  , chestcompression  , intubationformeconium  , intubationotherwise  , adrenaline  , volumeexpanders  , hypoxicischemicencephalopathy  , seizures  , IVH  , othersintracranialbleed  , diabetesotherthanGDM , heartdisease  , renaldisease  , hypertension  , seizuredisorder  , tuberculosis  , malaria  ,asthma  , hepatitisB  , syphilis  , HIVinfection  , ReceivedNurserycare24hr  , Antenatalsteroids  , Cardiacmalfunction  , hydrocephalus  , neuraltubeeffect  , cleftlippalate  , gestrointestinalmalformation  , genitourinarymalformation  , downsyndrome  , Initiatedwithin1hrofbirth  , Rhisoimmunisation  , hypothermia  , apneicspell  , hypoglycemia  , hypocalcemia  , anemia  , polycythemia  , NEC  , PDA  , VitaminKdeficiencybleeding  , Neonatalcholestasis  , Majorbirthtrauma  , CLD  , INfluids  , antibiotics  , OxygenTreatment , CPAP  , IMV  , Surfactant  , Bloodplasmatransfusion  , Phototherapy  , Exchangetransfusion  , Parenteralnutrition  , LaserforROP  , Anyothersurgery  , Septicemiapneumoniameningitis  , Tetanusneonatorum  , systemicsepsis  , misc_morbidity )values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
          //  Class.forName("com.mysql.jdbc.Driver"); //
            Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/aiimsbbs","root","1234asdf");
            PreparedStatement st = conn.prepareStatement(query);
            // combo boxes
            // 1 == column name/number, get(0) == recordData  element 0th position
            st.setString(1, data.get(0));
            st.setString(2, data.get(1));
            st.setString(3, data.get(2));
            st.setString(4, data.get(3));
            st.setString(5, data.get(4));
            st.setString(6, data.get(5));
            st.setString(7, data.get(6));
            st.setString(8, data.get(7));
            st.setString(9, data.get(8));
            st.setString(10, data.get(9));
            st.setString(11, data.get(10));
            st.setString(12, data.get(11));
            st.setString(13, data.get(12));
            st.setString(14, data.get(13));
            st.setString(15, data.get(14));
            st.setString(16, data.get(15));
            st.setString(17, data.get(16));
            st.setString(18, data.get(17));
            st.setString(19, data.get(18));
            st.setString(20, data.get(19));
            st.setString(21, data.get(20));
            st.setString(22, data.get(21));


            // text fields
            st.setString(23, data.get(22));
            st.setString(24, data.get(23));
            st.setString(25, data.get(24));
            st.setString(26, data.get(25));
            st.setString(27, data.get(26));
            st.setString(28, data.get(27));
            st.setString(29, data.get(28));
            st.setString(30, data.get(29));
            st.setString(31, data.get(30));
            st.setString(32, data.get(31));
            st.setString(33, data.get(32));
            st.setString(34, data.get(33));
            st.setString(35, data.get(34));
            st.setString(36, data.get(35));
            st.setString(37, data.get(36));
            st.setString(38, data.get(37));
            st.setString(39, data.get(38));
            st.setString(40, data.get(39));
            st.setString(41, data.get(40));
            st.setString(42, data.get(41));
            st.setString(43, data.get(42));
            st.setString(44, data.get(43));
            st.setString(45, data.get(44));
            st.setString(46, data.get(45));
            st.setString(47, data.get(46));
            st.setString(48, data.get(47));
            st.setString(49, data.get(48));
            st.setString(50, data.get(49));
            st.setString(51, data.get(50));
            st.setString(52, data.get(51));
            st.setString(53, data.get(52));
            st.setString(54, data.get(53));
            st.setString(55, data.get(54));

            // text area
            st.setString(56, data.get(55));
            st.setString(57, data.get(56));
            // check boxes
            st.setString(58, data.get(57));
            st.setString(59, data.get(58));
            st.setString(60, data.get(59));
            st.setString(61, data.get(60));
            st.setString(62, data.get(61));
            st.setString(63, data.get(62));
            st.setString(64, data.get(63));
            st.setString(65, data.get(64));
            st.setString(66, data.get(65));
            st.setString(67, data.get(66));
            st.setString(68, data.get(67));
            st.setString(69, data.get(68));
            st.setString(70, data.get(69));
            st.setString(71, data.get(70));
            st.setString(72, data.get(71));
            st.setString(73, data.get(72));
            st.setString(74, data.get(73));
            st.setString(75, data.get(74));
            st.setString(76, data.get(75));
            st.setString(77, data.get(76));
            st.setString(78, data.get(77));
            st.setString(79, data.get(78));
            st.setString(80, data.get(79));
            st.setString(81, data.get(80));
            st.setString(82, data.get(81));
            st.setString(83, data.get(82));
            st.setString(84, data.get(83));
            st.setString(85, data.get(84));
            st.setString(86, data.get(85));
            st.setString(87, data.get(86));
            st.setString(88, data.get(87));
            st.setString(89, data.get(88));
            st.setString(90, data.get(89));
            st.setString(91, data.get(90));
            st.setString(92, data.get(91));
            st.setString(93, data.get(92));
            st.setString(94, data.get(93));
            st.setString(95, data.get(94));
            st.setString(96, data.get(95));
            st.setString(97, data.get(96));
            st.setString(98, data.get(97));
            st.setString(99, data.get(98));
            st.setString(100, data.get(99));
            st.setString(101, data.get(100));
            st.setString(102, data.get(101));
            st.setString(103, data.get(102));
            st.setString(104, data.get(103));
            st.setString(105, data.get(104));
            st.setString(106, data.get(105));
            st.setString(107, data.get(106));
            st.setString(108, data.get(107));
            st.setString(109, data.get(108));
            st.setString(110, data.get(109));
            st.setString(111, data.get(110));
            st.setString(112, data.get(111));
            st.setString(113, data.get(112));
            st.setString(114, data.get(113));
            st.setString(115, data.get(114));
            st.setString(116, data.get(115));
            st.setString(117, data.get(116));
            st.setString(118, data.get(117));
            st.setString(119, data.get(118));
            st.setString(120, data.get(119));
            st.setString(121, data.get(120));
            st.setString(122, data.get(121));
            st.setString(123, data.get(122));
            st.setString(124, data.get(123));
            st.setString(125, data.get(124));
            st.setString(126, data.get(125));
            st.setString(127, data.get(126));
            st.setString(128, data.get(127));
            st.setString(129, data.get(128));
            st.setString(130, data.get(129));
            st.setString(131, data.get(130));
            st.setString(132, data.get(131));
            st.setString(133, data.get(132));
            st.setString(134, data.get(133));
            st.setString(135, data.get(134));
            st.setString(136, data.get(135));
            st.setString(137, data.get(136));
            st.setString(138, data.get(137));
            st.setString(139, data.get(138));
            st.setString(140, data.get(139));
            st.setString(141, data.get(140));
            st.setString(142, data.get(141));
            st.setString(143, data.get(142));
            st.setString(144, data.get(143));







            // execute the prepared statement insert
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}