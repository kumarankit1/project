package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class GBS {
    @FXML
    private  TextField txtGBSBHRN,txtGBSNo;


    @FXML
    private ComboBox cmbGBScc,cmbGBS1,cmbGBS2,cmbGBS3,cmbGBS4,cmbGBS5,cmbGBS6,cmbGBS7,cmbGBS8,cmbGBS9,cmbGBS10,cmbGBS11,cmbGBS12,cmbGBS13,cmbGBS14,cmbGBS15,cmbGBS16;

    @FXML
    public void initialize()
    {
        cmbGBScc.getItems().removeAll(cmbGBScc.getItems());
        cmbGBScc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbGBS1.getItems().removeAll(cmbGBS1.getItems());
        cmbGBS1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS2.getItems().removeAll(cmbGBS2.getItems());
        cmbGBS2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS3.getItems().removeAll(cmbGBS3.getItems());
        cmbGBS3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS4.getItems().removeAll(cmbGBS4.getItems());
        cmbGBS4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS5.getItems().removeAll(cmbGBS5.getItems());
        cmbGBS5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS6.getItems().removeAll(cmbGBS6.getItems());
        cmbGBS6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS7.getItems().removeAll(cmbGBS7.getItems());
        cmbGBS7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS8.getItems().removeAll(cmbGBS8.getItems());
        cmbGBS8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS9.getItems().removeAll(cmbGBS9.getItems());
        cmbGBS9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS10.getItems().removeAll(cmbGBS10.getItems());
        cmbGBS10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS11.getItems().removeAll(cmbGBS11.getItems());
        cmbGBS11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS12.getItems().removeAll(cmbGBS12.getItems());
        cmbGBS12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbGBS13.getItems().removeAll(cmbGBS13.getItems());
        cmbGBS13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbGBS14.getItems().removeAll(cmbGBS14.getItems());
        cmbGBS14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbGBS15.getItems().removeAll(cmbGBS15.getItems());
        cmbGBS15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbGBS16.getItems().removeAll(cmbGBS16.getItems());
        cmbGBS16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void GBS() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtGBSBHRN.getText());

        recordData.add(txtGBSNo.getText());

    }
}
