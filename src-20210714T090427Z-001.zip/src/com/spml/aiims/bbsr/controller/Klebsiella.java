package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class Klebsiella {
    @FXML
    private  TextField txtKlebsiellaBHRN,txtKlebsiellaNo;


    @FXML
    private ComboBox cmbKlebsiellacc,cmbKlebsiella1,cmbKlebsiella2,cmbKlebsiella3,cmbKlebsiella4,cmbKlebsiella5,cmbKlebsiella6,cmbKlebsiella7,cmbKlebsiella8,cmbKlebsiella9,cmbKlebsiella10,cmbKlebsiella11,cmbKlebsiella12,cmbKlebsiella13,cmbKlebsiella14,cmbKlebsiella15,cmbKlebsiella16;

    @FXML
    public void initialize()
    {
        cmbKlebsiellacc.getItems().removeAll(cmbKlebsiellacc.getItems());
        cmbKlebsiellacc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbKlebsiella1.getItems().removeAll(cmbKlebsiella1.getItems());
        cmbKlebsiella1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella2.getItems().removeAll(cmbKlebsiella2.getItems());
        cmbKlebsiella2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella3.getItems().removeAll(cmbKlebsiella3.getItems());
        cmbKlebsiella3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella4.getItems().removeAll(cmbKlebsiella4.getItems());
        cmbKlebsiella4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella5.getItems().removeAll(cmbKlebsiella5.getItems());
        cmbKlebsiella5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella6.getItems().removeAll(cmbKlebsiella6.getItems());
        cmbKlebsiella6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella7.getItems().removeAll(cmbKlebsiella7.getItems());
        cmbKlebsiella7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella8.getItems().removeAll(cmbKlebsiella8.getItems());
        cmbKlebsiella8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella9.getItems().removeAll(cmbKlebsiella9.getItems());
        cmbKlebsiella9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella10.getItems().removeAll(cmbKlebsiella10.getItems());
        cmbKlebsiella10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella11.getItems().removeAll(cmbKlebsiella11.getItems());
        cmbKlebsiella11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella12.getItems().removeAll(cmbKlebsiella12.getItems());
        cmbKlebsiella12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbKlebsiella13.getItems().removeAll(cmbKlebsiella13.getItems());
        cmbKlebsiella13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbKlebsiella14.getItems().removeAll(cmbKlebsiella14.getItems());
        cmbKlebsiella14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbKlebsiella15.getItems().removeAll(cmbKlebsiella15.getItems());
        cmbKlebsiella15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbKlebsiella16.getItems().removeAll(cmbKlebsiella16.getItems());
        cmbKlebsiella16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void Klebsiella() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtKlebsiellaBHRN.getText());

        recordData.add(txtKlebsiellaNo.getText());

    }
}
