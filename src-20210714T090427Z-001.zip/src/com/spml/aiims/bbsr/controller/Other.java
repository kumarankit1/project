package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class Other {
    @FXML
    private  TextField txtOtherBHRN,txtOtherNo;


    @FXML
    private ComboBox cmbOthercc,cmbOther1,cmbOther2,cmbOther3,cmbOther4,cmbOther5,cmbOther6,cmbOther7,cmbOther8,cmbOther9,cmbOther10,cmbOther11,cmbOther12,cmbOther13,cmbOther14,cmbOther15,cmbOther16;

    @FXML
    public void initialize()
    {
        cmbOthercc.getItems().removeAll(cmbOthercc.getItems());
        cmbOthercc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbOther1.getItems().removeAll(cmbOther1.getItems());
        cmbOther1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther2.getItems().removeAll(cmbOther2.getItems());
        cmbOther2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther3.getItems().removeAll(cmbOther3.getItems());
        cmbOther3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther4.getItems().removeAll(cmbOther4.getItems());
        cmbOther4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther5.getItems().removeAll(cmbOther5.getItems());
        cmbOther5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther6.getItems().removeAll(cmbOther6.getItems());
        cmbOther6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther7.getItems().removeAll(cmbOther7.getItems());
        cmbOther7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther8.getItems().removeAll(cmbOther8.getItems());
        cmbOther8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther9.getItems().removeAll(cmbOther9.getItems());
        cmbOther9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther10.getItems().removeAll(cmbOther10.getItems());
        cmbOther10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther11.getItems().removeAll(cmbOther11.getItems());
        cmbOther11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther12.getItems().removeAll(cmbOther12.getItems());
        cmbOther12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbOther13.getItems().removeAll(cmbOther13.getItems());
        cmbOther13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbOther14.getItems().removeAll(cmbOther14.getItems());
        cmbOther14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbOther15.getItems().removeAll(cmbOther15.getItems());
        cmbOther15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbOther16.getItems().removeAll(cmbOther16.getItems());
        cmbOther16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void Other() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtOtherBHRN.getText());

        recordData.add(txtOtherNo.getText());

    }
}
