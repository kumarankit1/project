package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class Pseudomonas {
    @FXML
    private  TextField txtPseudomonasBHRN,txtPseudomonasNo;


    @FXML
    private ComboBox cmbPseudomonascc,cmbPseudomonas1,cmbPseudomonas2,cmbPseudomonas3,cmbPseudomonas4,cmbPseudomonas5,cmbPseudomonas6,cmbPseudomonas7,cmbPseudomonas8,cmbPseudomonas9,cmbPseudomonas10,cmbPseudomonas11,cmbPseudomonas12,cmbPseudomonas13,cmbPseudomonas14,cmbPseudomonas15,cmbPseudomonas16;

    @FXML
    public void initialize()
    {
        cmbPseudomonascc.getItems().removeAll(cmbPseudomonascc.getItems());
        cmbPseudomonascc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbPseudomonas1.getItems().removeAll(cmbPseudomonas1.getItems());
        cmbPseudomonas1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas2.getItems().removeAll(cmbPseudomonas2.getItems());
        cmbPseudomonas2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas3.getItems().removeAll(cmbPseudomonas3.getItems());
        cmbPseudomonas3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas4.getItems().removeAll(cmbPseudomonas4.getItems());
        cmbPseudomonas4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas5.getItems().removeAll(cmbPseudomonas5.getItems());
        cmbPseudomonas5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas6.getItems().removeAll(cmbPseudomonas6.getItems());
        cmbPseudomonas6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas7.getItems().removeAll(cmbPseudomonas7.getItems());
        cmbPseudomonas7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas8.getItems().removeAll(cmbPseudomonas8.getItems());
        cmbPseudomonas8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas9.getItems().removeAll(cmbPseudomonas9.getItems());
        cmbPseudomonas9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas10.getItems().removeAll(cmbPseudomonas10.getItems());
        cmbPseudomonas10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas11.getItems().removeAll(cmbPseudomonas11.getItems());
        cmbPseudomonas11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas12.getItems().removeAll(cmbPseudomonas12.getItems());
        cmbPseudomonas12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbPseudomonas13.getItems().removeAll(cmbPseudomonas13.getItems());
        cmbPseudomonas13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbPseudomonas14.getItems().removeAll(cmbPseudomonas14.getItems());
        cmbPseudomonas14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbPseudomonas15.getItems().removeAll(cmbPseudomonas15.getItems());
        cmbPseudomonas15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbPseudomonas16.getItems().removeAll(cmbPseudomonas16.getItems());
        cmbPseudomonas16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void Pseudomonas() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtPseudomonasBHRN.getText());

        recordData.add(txtPseudomonasNo.getText());

    }
}
