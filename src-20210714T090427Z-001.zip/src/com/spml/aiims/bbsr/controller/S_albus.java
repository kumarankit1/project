package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class S_albus {
    @FXML
    private  TextField txtSalbusBHRN,txtSalbusNo;


    @FXML
    private ComboBox cmbSalbuscc,cmbSalbus1,cmbSalbus2,cmbSalbus3,cmbSalbus4,cmbSalbus5,cmbSalbus6,cmbSalbus7,cmbSalbus8,cmbSalbus9,cmbSalbus10,cmbSalbus11,cmbSalbus12,cmbSalbus13,cmbSalbus14,cmbSalbus15,cmbSalbus16;

    @FXML
    public void initialize()
    {
        cmbSalbuscc.getItems().removeAll(cmbSalbuscc.getItems());
        cmbSalbuscc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbSalbus1.getItems().removeAll(cmbSalbus1.getItems());
        cmbSalbus1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus2.getItems().removeAll(cmbSalbus2.getItems());
        cmbSalbus2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus3.getItems().removeAll(cmbSalbus3.getItems());
        cmbSalbus3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus4.getItems().removeAll(cmbSalbus4.getItems());
        cmbSalbus4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus5.getItems().removeAll(cmbSalbus5.getItems());
        cmbSalbus5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus6.getItems().removeAll(cmbSalbus6.getItems());
        cmbSalbus6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus7.getItems().removeAll(cmbSalbus7.getItems());
        cmbSalbus7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus8.getItems().removeAll(cmbSalbus8.getItems());
        cmbSalbus8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus9.getItems().removeAll(cmbSalbus9.getItems());
        cmbSalbus9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus10.getItems().removeAll(cmbSalbus10.getItems());
        cmbSalbus10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus11.getItems().removeAll(cmbSalbus11.getItems());
        cmbSalbus11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus12.getItems().removeAll(cmbSalbus12.getItems());
        cmbSalbus12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSalbus13.getItems().removeAll(cmbSalbus13.getItems());
        cmbSalbus13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbSalbus14.getItems().removeAll(cmbSalbus14.getItems());
        cmbSalbus14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbSalbus15.getItems().removeAll(cmbSalbus15.getItems());
        cmbSalbus15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbSalbus16.getItems().removeAll(cmbSalbus16.getItems());
        cmbSalbus16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void S_albus() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtSalbusBHRN.getText());

        recordData.add(txtSalbusNo.getText());

    }
}
