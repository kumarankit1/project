package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class S_aureus {
    @FXML
    private  TextField txtSaureusBHRN,txtSaureusNo;


    @FXML
    private ComboBox cmbSaureuscc,cmbSaureus1,cmbSaureus2,cmbSaureus3,cmbSaureus4,cmbSaureus5,cmbSaureus6,cmbSaureus7,cmbSaureus8,cmbSaureus9,cmbSaureus10,cmbSaureus11,cmbSaureus12,cmbSaureus13,cmbSaureus14,cmbSaureus15,cmbSaureus16;

    @FXML
    public void initialize()
    {
        cmbSaureuscc.getItems().removeAll(cmbSaureuscc.getItems());
        cmbSaureuscc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbSaureus1.getItems().removeAll(cmbSaureus1.getItems());
        cmbSaureus1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus2.getItems().removeAll(cmbSaureus2.getItems());
        cmbSaureus2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus3.getItems().removeAll(cmbSaureus3.getItems());
        cmbSaureus3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus4.getItems().removeAll(cmbSaureus4.getItems());
        cmbSaureus4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus5.getItems().removeAll(cmbSaureus5.getItems());
        cmbSaureus5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus6.getItems().removeAll(cmbSaureus6.getItems());
        cmbSaureus6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus7.getItems().removeAll(cmbSaureus7.getItems());
        cmbSaureus7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus8.getItems().removeAll(cmbSaureus8.getItems());
        cmbSaureus8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus9.getItems().removeAll(cmbSaureus9.getItems());
        cmbSaureus9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus10.getItems().removeAll(cmbSaureus10.getItems());
        cmbSaureus10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus11.getItems().removeAll(cmbSaureus11.getItems());
        cmbSaureus11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus12.getItems().removeAll(cmbSaureus12.getItems());
        cmbSaureus12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSaureus13.getItems().removeAll(cmbSaureus13.getItems());
        cmbSaureus13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbSaureus14.getItems().removeAll(cmbSaureus14.getItems());
        cmbSaureus14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbSaureus15.getItems().removeAll(cmbSaureus15.getItems());
        cmbSaureus15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbSaureus16.getItems().removeAll(cmbSaureus16.getItems());
        cmbSaureus16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void S_aureus() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtSaureusBHRN.getText());

        recordData.add(txtSaureusNo.getText());

    }
}
