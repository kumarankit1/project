package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;

public class S_viridans {
    @FXML
    private  TextField txtSviridansBHRN,txtSviridansNo;


    @FXML
    private ComboBox cmbSviridanscc,cmbSviridans1,cmbSviridans2,cmbSviridans3,cmbSviridans4,cmbSviridans5,cmbSviridans6,cmbSviridans7,cmbSviridans8,cmbSviridans9,cmbSviridans10,cmbSviridans11,cmbSviridans12,cmbSviridans13,cmbSviridans14,cmbSviridans15,cmbSviridans16;

    @FXML
    public void initialize()
    {
        cmbSviridanscc.getItems().removeAll(cmbSviridanscc.getItems());
        cmbSviridanscc.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");


        cmbSviridans1.getItems().removeAll(cmbSviridans1.getItems());
        cmbSviridans1.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans2.getItems().removeAll(cmbSviridans2.getItems());
        cmbSviridans2.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans3.getItems().removeAll(cmbSviridans3.getItems());
        cmbSviridans3.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans4.getItems().removeAll(cmbSviridans4.getItems());
        cmbSviridans4.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans5.getItems().removeAll(cmbSviridans5.getItems());
        cmbSviridans5.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans6.getItems().removeAll(cmbSviridans6.getItems());
        cmbSviridans6.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans7.getItems().removeAll(cmbSviridans7.getItems());
        cmbSviridans7.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans8.getItems().removeAll(cmbSviridans8.getItems());
        cmbSviridans8.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans9.getItems().removeAll(cmbSviridans9.getItems());
        cmbSviridans9.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans10.getItems().removeAll(cmbSviridans10.getItems());
        cmbSviridans10.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans11.getItems().removeAll(cmbSviridans11.getItems());
        cmbSviridans11.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans12.getItems().removeAll(cmbSviridans12.getItems());
        cmbSviridans12.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");


        cmbSviridans13.getItems().removeAll(cmbSviridans13.getItems());
        cmbSviridans13.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbSviridans14.getItems().removeAll(cmbSviridans14.getItems());
        cmbSviridans14.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");



        cmbSviridans15.getItems().removeAll(cmbSviridans15.getItems());
        cmbSviridans15.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");

        cmbSviridans16.getItems().removeAll(cmbSviridans16.getItems());
        cmbSviridans16.getItems().addAll("Not known", "Sensitive","Resistant","Partially Sensitive");
    }

    @FXML
    private void S_viridans() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtSviridansBHRN.getText());

        recordData.add(txtSviridansNo.getText());

    }
}
