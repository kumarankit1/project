package com.spml.aiims.bbsr.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.ArrayList;

public class StillBirthHelper {
    public void saveRecord(ArrayList<String> data){

        System.out.println(data.get(0));
        System.out.println(data.get(1));
    }

    public void insertDatabase(ArrayList<String> data) {
        try {
            String query = "insert into stillbirths(entryid ,Centercode  , Sex  , Singlemultiple  , modeofdelivery  , PreviousIUGR  , Antenatalcare  , oftheabovecauses  , didthemotherdie  , causeofdeath  , whendetected  , whetherfreshormacerated  , Babyhospitalrecordno  , NNPD_SB_nb  , mothername  , Dateofbirth  , TimeofBirth24hrs  , Birthweight  , Gestation  , Maternalage  , Gravida  , Para  , Abortion  , Stillbirth , Others  , DateofDeath  , Dataenteredby  , Supervisedby  , Othersmedicalproblems  , Non_vertexpresentation  , Oxyfocinuse  , Prolongedruptureofmembranes18h  , Meconiumstainedliquor  , Foulsmellingliquor  , Severeanemia  , Pregnancyinducedhypertension  , Preeclamptictoxemia  , eclampsia  , gestationaldiabetes  , Oligohydraminos  , polyhydraminos  , cephalopelvicdisproportion  , previouscaesereandelivery  , antepartuheamorrhage  , Placentaprevia  , abruptioplacenta  , Asphyxia  , Trauma  , congenitalmalformation  , infection  , Rhisoimmunisation  , Otherscauseofdeath, Notestablished  , diabetesotherthangestationalDM , heartdisease  , renaldisease  , hypertensionotherthanpregnancyinduced  , seizuredisorder  , tuberclosis  , malaria  , asthma  , hepatitis  , syphilis  , HIVinfection  )values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            // Class.forName("com.mysql.jdbc.Driver"); //
            Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/aiimsbbs","root","1234asdf");
            PreparedStatement st = conn.prepareStatement(query);

            // combo boxes
            // 1 == column name/number, get(0) == recordData  element 0th position
            st.setString(1, data.get(0));
            st.setString(2, data.get(1));
            st.setString(3, data.get(2));
            st.setString(4, data.get(3));
            st.setString(5, data.get(4));
            st.setString(6, data.get(5));
            st.setString(7, data.get(6));
            st.setString(8, data.get(7));
            st.setString(9, data.get(8));
            st.setString(10, data.get(9));
            st.setString(11, data.get(10));

            // text fields
            st.setString(12, data.get(11));
            st.setString(13, data.get(12));
            st.setString(14, data.get(13));
            st.setString(15, data.get(14));
            st.setString(16, data.get(15));
            st.setString(17, data.get(16));
            st.setString(18, data.get(17));
            st.setString(19, data.get(18));
            st.setString(20, data.get(19));
            st.setString(21, data.get(20));
            st.setString(22, data.get(21));
            st.setString(23, data.get(22));
            st.setString(24, data.get(23));
            st.setString(25, data.get(24));
            st.setString(26, data.get(25));
            st.setString(27, data.get(26));
            st.setString(28, data.get(27));
            // check boxes
            st.setString(29, data.get(28));
            st.setString(30, data.get(29));
            st.setString(31, data.get(30));
            st.setString(32, data.get(31));
            st.setString(33, data.get(32));
            st.setString(34, data.get(33));
            st.setString(35, data.get(34));
            st.setString(36, data.get(35));
            st.setString(37, data.get(36));
            st.setString(38, data.get(37));
            st.setString(39, data.get(38));
            st.setString(40, data.get(39));
            st.setString(41, data.get(40));
            st.setString(42, data.get(41));
            st.setString(43, data.get(42));
            st.setString(44, data.get(43));
            st.setString(45, data.get(44));
            st.setString(46, data.get(45));
            st.setString(47, data.get(46));
            st.setString(48, data.get(47));
            st.setString(49, data.get(48));
            st.setString(50, data.get(49));
            st.setString(51, data.get(50));
            st.setString(52, data.get(51));
            st.setString(53, data.get(52));
            st.setString(54, data.get(53));
            st.setString(55, data.get(54));
            st.setString(56, data.get(55));
            st.setString(57, data.get(56));
            st.setString(58, data.get(57));
            st.setString(59, data.get(58));
            st.setString(60, data.get(59));
            st.setString(61, data.get(60));
            st.setString(62, data.get(61));
            st.setString(63, data.get(62));
            st.setString(64, data.get(63));










            // execute the prepared statement insert
            st.executeUpdate();
            st.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
}
