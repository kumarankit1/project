package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import javafx.fxml.FXML;

import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;


public class Systematic_sepsis {
    @FXML
    private  TextField txtssBHRN,txtssNNPD,txtssEN1,txtssEN2,txtssEN3,txtssEN4,txtssDOL1,txtssDOL2,txtssDOL3,txtssDOL4,txtssDAYS1,txtssDAYS2,txtssDAYS3,txtssDAYS4,txtssDURATION1a,txtssDURATION1b,txtssDURATION1c,txtssDURATION2a,txtssDURATION2b,txtssDURATION2c,txtssDURATION3a,txtssDURATION3b,txtssDURATION3c,txtssDURATION4a,txtssDURATION4b,txtssDURATION4c;

    @FXML
    private ComboBox cmbSSCC,cmbSSOOS1,cmbSSOOS2,cmbSSOOS3,cmbSSOOS4,cmbSSCulture1,cmbSSCulture2,cmbSSCulture3,cmbSSCulture4,cmbSSAg1a,cmbSSAg1b,cmbSSAg1c,cmbSSAg2a,cmbSSAg2b,cmbSSAg2c,cmbSSAg3a,cmbSSAg3b,cmbSSAg3c,cmbSSAg4a,cmbSSAg4b,cmbSSAg4c;

    @FXML
    public void initialize(){
        cmbSSCC.getItems().removeAll(cmbSSCC.getItems());
        cmbSSCC.getItems().addAll("India", "Thailand", "Bangladesh","Indonesia","Nepal");

        cmbSSOOS1.getItems().removeAll(cmbSSOOS1.getItems());
        cmbSSOOS1.getItems().addAll("Early", "Late");

        cmbSSOOS2.getItems().removeAll(cmbSSOOS2.getItems());
        cmbSSOOS2.getItems().addAll("Early", "Late");

        cmbSSOOS3.getItems().removeAll(cmbSSOOS3.getItems());
        cmbSSOOS3.getItems().addAll("Early", "Late");

        cmbSSOOS4.getItems().removeAll(cmbSSOOS4.getItems());
        cmbSSOOS4.getItems().addAll("Early", "Late");

        cmbSSCulture1.getItems().removeAll(cmbSSCulture1.getItems());
        cmbSSCulture1.getItems().addAll("+ve", "-ve");

        cmbSSCulture2.getItems().removeAll(cmbSSCulture2.getItems());
        cmbSSCulture2.getItems().addAll("+ve", "-ve");

        cmbSSCulture3.getItems().removeAll(cmbSSCulture3.getItems());
        cmbSSCulture3.getItems().addAll("+ve", "-ve");

        cmbSSCulture4.getItems().removeAll(cmbSSCulture4.getItems());
        cmbSSCulture4.getItems().addAll("+ve", "-ve");

        cmbSSAg1a.getItems().removeAll(cmbSSAg1a.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1b.getItems().removeAll(cmbSSAg1b.getItems());
        cmbSSAg1b.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1c.getItems().removeAll(cmbSSAg1c.getItems());
        cmbSSAg1c.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1a.getItems().removeAll(cmbSSAg2a.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");


        cmbSSAg1a.getItems().removeAll(cmbSSAg2b.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1a.getItems().removeAll(cmbSSAg2c.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1a.getItems().removeAll(cmbSSAg3a.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1a.getItems().removeAll(cmbSSAg3b.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1a.getItems().removeAll(cmbSSAg3c.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1a.getItems().removeAll(cmbSSAg4a.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");


        cmbSSAg1a.getItems().removeAll(cmbSSAg4b.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");

        cmbSSAg1a.getItems().removeAll(cmbSSAg4c.getItems());
        cmbSSAg1a.getItems().addAll("Pencillin", "Ampicillin","Cloxacillin","Gentamicin","Amikacin","Netilmicin","Cefazolin","Cephelexin","Ceftizoxime","Cefotaxime","Ceftriioxone","Cefoperazone","Ceftazidime","Piperacilllin","Vancomycin","Ciprofloxacin","Meropenam","Imipenam","Piperacillin-Tazobactum","Cefotaxime-Sulbactum","Linezolid","Metronidazole","Fluconazole","Amphotericin B","Cefoperazone-Sulbactum","Amoxycillin-Clauvulanic Acid","Cefipime","Cefixime","Erythromycin","Chloramphenicol","Amoxycillin","Ampicillin Sulfactum","Ofloxacin","Azithromycin");


    }


    @FXML
    private void systematic_sepsis() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();

        recordData.add(txtssBHRN.getText());
        recordData.add(txtssNNPD.getText());
        recordData.add(txtssEN1.getText());
        recordData.add(txtssEN2.getText());
        recordData.add(txtssEN3.getText());
        recordData.add(txtssEN4.getText());
        recordData.add(txtssDOL1.getText());
        recordData.add(txtssDOL2.getText());
        recordData.add(txtssDOL3.getText());
        recordData.add(txtssDOL4.getText());
        recordData.add(txtssDAYS1.getText());
        recordData.add(txtssDAYS2.getText());
        recordData.add(txtssDAYS3.getText());
        recordData.add(txtssDAYS4.getText());
        recordData.add(txtssDURATION1a.getText());
        recordData.add(txtssDURATION1b.getText());
        recordData.add(txtssDURATION1c.getText());
        recordData.add(txtssDURATION2a.getText());
        recordData.add(txtssDURATION2b.getText());
        recordData.add(txtssDURATION2c.getText());
        recordData.add(txtssDURATION3a.getText());
        recordData.add(txtssDURATION3b.getText());
        recordData.add(txtssDURATION3c.getText());
        recordData.add(txtssDURATION4a.getText());
        recordData.add(txtssDURATION4b.getText());
        recordData.add(txtssDURATION4c.getText());

    }


}
