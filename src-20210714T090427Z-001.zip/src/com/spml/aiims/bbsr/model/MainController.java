package com.spml.aiims.bbsr.model;
import java.io.IOException;
import java.util.ArrayList;


import com.sun.source.tree.IfTree;
import jdk.jfr.DataAmount;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.spml.aiims.bbsr.controller.IntraMuralHelper;
import com.spml.aiims.bbsr.controller.StillBirthHelper;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import com.spml.aiims.bbsr.controller.ExtraMuralHelper;


public class MainController {

    // IntraMural GUI Elements - TextField
    @FXML
    private TextField txtIntraBRecordNo, txtIntraMname, txtIntraDOB, txtIntraTOB, txtIntraBW, txtIntraGes, txtIntraAp1, txtIntraAp5, txtIntraAp10;
    @FXML
    private TextField txtIntraLSCS, txtIntraFname, txtIntraAdd, txtIntraTel, txtIntraDate1, txtIntraDate2, txtIntraDate3;
    @FXML
    private TextField txtIntraMD1, txtIntraMD2, txtIntraMD3, txtIntraMD4, txtIntraMD5, txtIntraMD6;
    @FXML
    private TextField txtIntraOB, txtIntraTSH, txtIntraTSHD, txtIntraMP, txtIntraRD, txtIntraCNS, txtIntraMMa, txtIntraMMi;
    @FXML
    private TextField txtIntraTreat1, txtIntraTreat2, txtIntraTreat3, txtIntraDiag, txtIntraDOD, txtIntraWAD, txtIntraHC, txtIntraDEB, txtIntraSB, txtIntraIAD, txtIntraNNPD;
    // IntraMural GUI Elements - ComboBox
    @FXML
    private ComboBox cmbIntraCCode, cmbIntraHRB, cmbIntraRead, cmbIntraSex, cmbIntraMod, cmbIntraBaabb, cmbIntraMBG, cmbIntraBBG;
    @FXML
    private ComboBox cmbIntraHS, cmbIntraRR, cmbIntraCCHD, cmbIntraOAE, cmbIntraSM, cmbIntraMD1, cmbIntraMD2, cmbIntraMD3, cmbIntraMD4;
    @FXML
    private ComboBox cmbIntraMP, cmbIntraMMi, cmbIntraOutcome, cmbIntraMD, cmbIntraHC, cmbIntraIGC;
    // IntraMural GUI Elements - CheckBox
    @FXML
    private CheckBox chkIntraOP1, chkIntraOP2, chkIntraOP3, chkIntraOP4, chkIntraOP5, chkIntraOP6, chkIntraOP7, chkIntraOP8, chkIntraOP9, chkIntraOP10, chkIntraOP11, chkIntraOP12, chkIntraOP13;
    @FXML
    private CheckBox chkIntraND1, chkIntraND2, chkIntraND3, chkIntraND4, chkIntraND5, chkIntraND6, chkIntraND7, chkIntraND8;
    @FXML
    private CheckBox chkIntraMP1, chkIntraMP2, chkIntraMP3, chkIntraMP4, chkIntraMP5, chkIntraMP6, chkIntraMP7, chkIntraMP8, chkIntraMP9, chkIntraMP10,chkIntraMP11;
    @FXML
    private CheckBox chkIntraLD1, chkIntraLD2, chkIntraLD3, chkIntraLD4, chkIntraLD5, chkIntraLD6, chkIntraLD7;
    @FXML
    private CheckBox chkIntraRD1, chkIntraRD2, chkIntraRD3, chkIntraRD4, chkIntraRD5, chkIntraCNS1, chkIntraCNS2, chkIntraCNS3, chkIntraCNS4;
    @FXML
    private CheckBox chkIntraNC, chkIntraAS, chkIntraMMa1, chkIntraMMa2, chkIntraMMa3, chkIntraMMa4, chkIntraMMa5, chkIntraMMa6, chkIntraMMa7;
    @FXML
    private CheckBox chkIntraMMi1, chkIntraMMi2, chkIntraMMi3, chkIntraMMi4, chkIntraMMi5, chkIntraMMi6, chkIntraMMi7, chkIntraMMi8, chkIntraMMi9, chkIntraMMi10, chkIntraMMi11, chkIntraMMi12, chkIntraMMi13;
    @FXML
    private CheckBox chkIntraTreat1, chkIntraTreat2, chkIntraTreat3, chkIntraTreat4, chkIntraTreat5, chkIntraTreat6, chkIntraTreat7, chkIntraTreat8, chkIntraTreat9, chkIntraTreat10, chkIntraTreat11, chkIntraTreat12;
    @FXML
    private CheckBox chkIntraSI1, chkIntraSI2, chkIntraSI3, chkIntraSS, chkIntraMMo;

    // STILL BIRTH
    @FXML
    private TextField txtBirthBHRN, txtBirthNNPD, txtBirthMname, txtBirthDOB, txtBirthTPfB, txtBirthBW, txtBirthGES;
    @FXML
    private TextField txtBirthMD1, txtBirthMD2, txtBirthMD3, txtBirthMD4, txtBirthMD5, txtBirthOP, txtBirthMDe1, txtBirthMDe2, txtBirthMDe3, txtBirthMP;

    @FXML
    private ComboBox cmbBirthCcode, cmbBirthSex, cmbBirthSm, cmbBirthMOD, cmbBirthMD1, cmbBirthMD2, cmbBirthCOD, cmbBirthMDe1, cmbBirthMDe2, cmbBirthSB1, cmbBirthSB2;
    @FXML
    private CheckBox chkBirthLabor1, chkBirthLabor2, chkBirthLabor3, chkBirthLabor4, chkBirthLabor5;
    @FXML
    private CheckBox chkBirthOP1, chkBirthOP2, chkBirthOP3, chkBirthOP4, chkBirthOP5, chkBirthOP6, chkBirthOP7, chkBirthOP8, chkBirthOP9, chkBirthOP10, chkBirthOP11, chkBirthOP12;
    @FXML
    private CheckBox chkBirthCOD1, chkBirthCOD2, chkBirthCOD3, chkBirthCOD4, chkBirthCOD5, chkBirthCOD6, chkBirthCOD7;
    @FXML
    private CheckBox chkBirthMP1, chkBirthMP2, chkBirthMP3, chkBirthMP4, chkBirthMP5, chkBirthMP6, chkBirthMP7, chkBirthMP8, chkBirthMP9, chkBirthMP10, chkBirthMP11;



    // ExtraMural GUI Elements - TextField



    @FXML
    private TextField txtExtraBRecordNo,txtExtraMname,txtExtraDOB,txtExtraTOB,txtExtraBW,txtExtraGes,txtExtraAp1,txtExtraAp5,txtExtraAp10;
    @FXML
    private TextField txtExtraFname,txtExtraAdd,txtExtraTel;
    @FXML
    private TextField txtExtraMD1,txtExtraMD2,txtExtraMD3,txtExtraMD4,txtExtraMD5,txtExtraMD6;
    @FXML
    private TextField txtExtraOP,txtExtraMP,txtExtraRD,txtExtraCNS,txtExtraMMa,txtExtraMMi;
    @FXML
    private TextField txtExtraTreat1,txtExtraTreat2,txtExtraTreat3,txtExtraDiag,txtExtraDOD,txtExtraWAD,txtExtraHC,txtExtraDEB,txtExtraSB,txtExtraIAD,txtExtraNNPD;
    // ExtraMural GUI Elements - ComboBox
    @FXML
    private ComboBox cmbExtraCCode,cmbExtraHRB,cmbExtraRead,cmbExtraSex,cmbExtraMod,cmbExtraBaabb,cmbExtraMBG,cmbExtraBBG;
    @FXML
    private ComboBox cmbExtraHS,cmbExtraRR,cmbExtraLE,cmbExtraRE,cmbExtraSM,cmbExtraMD1,cmbExtraMD3,cmbExtraMD4;
    @FXML
    private ComboBox cmbExtraMP,cmbExtraMMi,cmbExtraOutcome,cmbExtraMD,cmbExtraHC,cmbExtraIGC,cmbExtraBF;
    // ExtraMural GUI Elements - CheckBox
    @FXML
    private CheckBox chkExtraOP1,chkExtraOP2,chkExtraOP3,chkExtraOP4,chkExtraOP5,chkExtraOP6,chkExtraOP7,chkExtraOP8,chkExtraOP9,chkExtraOP10,chkExtraOP11,chkExtraOP12;
    @FXML
    private CheckBox chkExtraND1,chkExtraND2,chkExtraND3,chkExtraND4,chkExtraND5,chkExtraND6,chkExtraND7;
    @FXML
    private CheckBox chkExtraMP1,chkExtraMP2,chkExtraMP3,chkExtraMP4,chkExtraMP5,chkExtraMP6,chkExtraMP7,chkExtraMP8,chkExtraMP9,chkExtraMP10,chkExtraMP11;
    @FXML
    private CheckBox chkExtraLD1,chkExtraLD2,chkExtraLD3,chkExtraLD4,chkExtraLD5,chkExtraLD6,chkExtraLD7;
    @FXML
    private CheckBox chkExtraRD1,chkExtraRD2,chkExtraRD3,chkExtraRD4,chkExtraRD5,chkExtraCNS1,chkExtraCNS2,chkExtraCNS3,chkExtraCNS4;
    @FXML
    private CheckBox chkExtraNC,chkExtraAS,chkExtraMMa1,chkExtraMMa2,chkExtraMMa3,chkExtraMMa4,chkExtraMMa5,chkExtraMMa6,chkExtraMMa7;
    @FXML
    private CheckBox chkExtraMMi1,chkExtraMMi2,chkExtraMMi3,chkExtraMMi4,chkExtraMMi5,chkExtraMMi6,chkExtraMMi7,chkExtraMMi8,chkExtraMMi9,chkExtraMMi10,chkExtraMMi11,chkExtraMMi12,chkExtraMMi13;
    @FXML
    private CheckBox chkExtraTreat1,chkExtraTreat2,chkExtraTreat3,chkExtraTreat4,chkExtraTreat5,chkExtraTreat6,chkExtraTreat7,chkExtraTreat8,chkExtraTreat9,chkExtraTreat10,chkExtraTreat11,chkExtraTreat12;
    @FXML
    private CheckBox chkExtraSI1,chkExtraSI2,chkExtraSS,chkExtraMMo,chkExtraBF;
    @FXML
    private Button IntraSaveRecord;
    @FXML
    public void initialize() {
        cmbIntraCCode.getItems().removeAll(cmbIntraCCode.getItems());
        cmbIntraCCode.getItems().addAll("None","India", "Option B", "Option C");
        cmbIntraCCode.getSelectionModel().selectFirst();

        cmbIntraHRB.getItems().removeAll(cmbIntraHRB.getItems());
        cmbIntraHRB.getItems().addAll("None","Yes", "No");
        cmbIntraHRB .getSelectionModel().selectFirst();

        cmbIntraRead.getItems().removeAll(cmbIntraRead.getItems());
        cmbIntraRead.getItems().addAll("None","Yes", "No");
        cmbIntraRead.getSelectionModel().selectFirst();

        cmbIntraSex.getItems().removeAll(cmbIntraSex.getItems());
        cmbIntraSex.getItems().addAll("None","Ambiguous", "Female", "Male");
        cmbIntraSex .getSelectionModel().selectFirst();

        cmbIntraMod.getItems().removeAll(cmbIntraMod.getItems());
        cmbIntraMod.getItems().addAll("None","Elective CS", "Emergency CS", "Forceps", "Normal", "Others", "Vacuum");
        cmbIntraMod.getSelectionModel().selectFirst();
        cmbIntraBaabb.getItems().removeAll(cmbIntraBaabb.getItems());
        cmbIntraBaabb.getItems().addAll("None","Doctor", "Nurse/MidWife");
        cmbIntraBaabb.getSelectionModel().selectFirst();
        cmbIntraMBG.getItems().removeAll(cmbIntraMBG.getItems());
        cmbIntraMBG.getItems().addAll("None","A Positive", "A Negative", "B Positive", "B Negative", "AB Positive", "AB Negative", "O Positive", "O Negative");
        cmbIntraMBG.getSelectionModel().selectFirst();
        cmbIntraBBG.getItems().removeAll(cmbIntraBBG.getItems());
        cmbIntraBBG.getItems().addAll("None","A Positive", "A Negative", "B Positive", "B Negative", "AB Positive", "AB Negative", "O Positive", "O Negative");
        cmbIntraBBG .getSelectionModel().selectFirst();
        cmbIntraHS.getItems().removeAll(cmbIntraHS.getItems());
        cmbIntraHS.getItems().addAll("None","Not Done", "OAE", "ABR");
        cmbIntraHS.getSelectionModel().selectFirst();
        cmbIntraRR.getItems().removeAll(cmbIntraRR.getItems());
        cmbIntraRR.getItems().addAll("None","Not Checked", "Present(RE)", "Present(LE)", "Present(BE)");
        cmbIntraRR.getSelectionModel().selectFirst();
        cmbIntraCCHD.getItems().removeAll(cmbIntraCCHD.getItems());
        cmbIntraCCHD.getItems().addAll("None","Not Done", "Positive", "Negative");
        cmbIntraCCHD.getSelectionModel().selectFirst();
        cmbIntraOAE.getItems().removeAll(cmbIntraOAE.getItems());
        cmbIntraOAE.getItems().addAll("None","Pass", "Referred", "Not Done");
        cmbIntraOAE .getSelectionModel().selectFirst();
        cmbIntraSM.getItems().removeAll(cmbIntraSM.getItems());
        cmbIntraSM.getItems().addAll("None","Single", "Twin 1", "Twin 2", "Triplet 1", "Triplet 2", "Triplet 3", "Higher Order");
        cmbIntraSM.getSelectionModel().selectFirst();
        cmbIntraMD1.getItems().removeAll(cmbIntraMD1.getItems());
        cmbIntraMD1.getItems().addAll("None","I", "II");
        cmbIntraMD1.getSelectionModel().selectFirst();
        cmbIntraMD2.getItems().removeAll(cmbIntraMD2.getItems());
        cmbIntraMD2.getItems().addAll("None","Dr S.K Jena", "Dr S.S Behera", "Dr S Mitra", "Dr S Singh", "Dr P Sethi", "J Begum");
        cmbIntraMD2.getSelectionModel().selectFirst();
        cmbIntraMD3.getItems().removeAll(cmbIntraMD3.getItems());
        cmbIntraMD3.getItems().addAll("None","No", "Not Known", "Yes");
        cmbIntraMD3.getSelectionModel().selectFirst();
        cmbIntraMD4.getItems().removeAll(cmbIntraMD4.getItems());
        cmbIntraMD4.getItems().addAll("None","India", "Option B", "Option C");
        cmbIntraMD4.getSelectionModel().selectFirst();
        cmbIntraMP.getItems().removeAll(cmbIntraMP.getItems());
        cmbIntraMP.getItems().addAll("None","Booked", "Unbooked");
        cmbIntraMP.getSelectionModel().selectFirst();
        cmbIntraMMi.getItems().removeAll(cmbIntraMMi.getItems());
        cmbIntraMMi.getItems().addAll("None","No", "Not Known", "Yes");
        cmbIntraMMi.getSelectionModel().selectFirst();
        cmbIntraOutcome.getItems().removeAll(cmbIntraOutcome.getItems());
        cmbIntraOutcome.getItems().addAll("None","Died", "Discharged", "Left Against Advice", "Referred");
        cmbIntraOutcome.getSelectionModel().selectFirst();
        cmbIntraMD.getItems().removeAll(cmbIntraMD.getItems());
        cmbIntraMD.getItems().addAll("None","No", "Not Known", "Yes");
        cmbIntraMD.getSelectionModel().selectFirst();
        cmbIntraHC.getItems().removeAll(cmbIntraHC.getItems());
        cmbIntraHC.getItems().addAll("None","Uneventful");
        cmbIntraHC.getSelectionModel().selectFirst();
        cmbIntraIGC.getItems().removeAll(cmbIntraIGC.getItems());
        cmbIntraIGC.getItems().addAll("None","Appropriate for dates", "Large for dates", "Small for dates");
        cmbIntraIGC.getSelectionModel().selectFirst();

        cmbExtraCCode.getItems().removeAll(cmbExtraCCode.getItems());
        cmbExtraCCode.getItems().addAll("None","India", "Option B", "Option C");
        cmbExtraCCode.getSelectionModel().selectFirst();
        cmbExtraBF.getItems().removeAll(cmbExtraBF.getItems());
        cmbExtraBF.getItems().addAll("None","Exclusive Breastfeeding", "Partial Breastfeeding","No Breastfeeding","Full Breastfeeding","Not Applicable");
        cmbExtraBF.getSelectionModel().selectFirst();
        cmbExtraHRB.getItems().removeAll(cmbExtraHRB.getItems());
        cmbExtraHRB.getItems().addAll("None","Yes", "No");
        cmbExtraHRB.getSelectionModel().selectFirst();
        cmbExtraRead.getItems().removeAll(cmbExtraRead.getItems());
        cmbExtraRead.getItems().addAll("None","Yes", "No");
        cmbExtraRead.getSelectionModel().selectFirst();
        cmbExtraSex.getItems().removeAll(cmbExtraSex.getItems());
        cmbExtraSex.getItems().addAll("None","Ambiguous", "Female", "Male");
        cmbExtraSex.getSelectionModel().selectFirst();
        cmbExtraMod.getItems().removeAll(cmbExtraMod.getItems());
        cmbExtraMod.getItems().addAll("None","Elective CS", "Emergency CS", "Forceps","Normal","Others","Vacuum");
        cmbExtraMod.getSelectionModel().selectFirst();
        cmbExtraBaabb.getItems().removeAll(cmbExtraBaabb.getItems());
        cmbExtraBaabb.getItems().addAll("None","Doctor", "Nurse/MidWife");
        cmbExtraBaabb.getSelectionModel().selectFirst();
        cmbExtraMBG.getItems().removeAll(cmbExtraMBG.getItems());
        cmbExtraMBG.getItems().addAll("None","A Positive", "A Negative", "B Positive","B Negative","AB Positive","AB Negative","O Positive","O Negative");
        cmbExtraMBG.getSelectionModel().selectFirst();
        cmbExtraBBG.getItems().removeAll(cmbExtraBBG.getItems());
        cmbExtraBBG.getItems().addAll("None","A Positive", "A Negative", "B Positive","B Negative","AB Positive","AB Negative","O Positive","O Negative");
        cmbExtraBBG.getSelectionModel().selectFirst();
        cmbExtraHS.getItems().removeAll(cmbExtraHS.getItems());
        cmbExtraHS.getItems().addAll("None","Not Done", "OAE", "ABR");
        cmbExtraHS.getSelectionModel().selectFirst();
        cmbExtraRR.getItems().removeAll(cmbExtraRR.getItems());
        cmbExtraRR.getItems().addAll("None","Not Checked", "Present(RE)", "Present(LE)","Present(BE)");

        cmbExtraRR.getSelectionModel().selectFirst();

        cmbExtraSM.getItems().removeAll(cmbExtraSM.getItems());
        cmbExtraSM.getItems().addAll("None","Single", "Twin 1", "Twin 2","Triplet 1","Triplet 2","Triplet 3","Higher Order");
        cmbExtraSM.getSelectionModel().selectFirst();
        cmbExtraMD1.getItems().removeAll(cmbExtraMD1.getItems());
        cmbExtraMD1.getItems().addAll("None","I", "II");
        cmbExtraMD1.getSelectionModel().selectFirst();


        cmbExtraMD3.getItems().removeAll(cmbExtraMD3.getItems());
        cmbExtraMD3.getItems().addAll("None","No", "Not Known", "Yes");
        cmbExtraMD3.getSelectionModel().selectFirst();
        cmbExtraMD4.getItems().removeAll(cmbExtraMD4.getItems());
        cmbExtraMD4.getItems().addAll("None","India", "Option B", "Option C");
        cmbExtraMD4.getSelectionModel().selectFirst();
        cmbExtraMP.getItems().removeAll(cmbExtraMP.getItems());
        cmbExtraMP.getItems().addAll("None","Booked", "Unbooked");
        cmbExtraMP.getSelectionModel().selectFirst();
        cmbExtraMMi.getItems().removeAll(cmbExtraMMi.getItems());
        cmbExtraMMi.getItems().addAll("None","No", "Not Known", "Yes");
        cmbExtraMMi.getSelectionModel().selectFirst();
        cmbExtraOutcome.getItems().removeAll(cmbExtraOutcome.getItems());
        cmbExtraOutcome.getItems().addAll("None","Died", "Discharged", "Left Against Advice","Referred");
        cmbExtraOutcome.getSelectionModel().selectFirst();
        cmbExtraMD.getItems().removeAll(cmbExtraMD.getItems());
        cmbExtraMD.getItems().addAll("None","No", "Not Known", "Yes");
        cmbExtraMD.getSelectionModel().selectFirst();
        cmbExtraHC.getItems().removeAll(cmbExtraHC.getItems());
        cmbExtraHC.getItems().addAll("None","Uneventful");
        cmbExtraHC.getSelectionModel().selectFirst();
        cmbExtraIGC.getItems().removeAll(cmbExtraIGC.getItems());
        cmbExtraIGC.getItems().addAll("None","Appropriate for dates", "Large for dates", "Small for dates");
        cmbExtraIGC.getSelectionModel().selectFirst();
        // extramural initialise

        cmbBirthCcode.getItems().removeAll(cmbBirthCcode.getItems());
        cmbBirthCcode.getItems().addAll("None","India", "Sri Lanka ", "Bangladesh","Thailand","Nepal");
        cmbBirthCcode.getSelectionModel().selectFirst();
        cmbBirthSex.getItems().removeAll(cmbBirthSex.getItems());
        cmbBirthSex.getItems().addAll("None","Ambiguous", "Female", "Male");
        cmbBirthSex.getSelectionModel().selectFirst();
        cmbBirthSm.getItems().removeAll(cmbBirthSm.getItems());
        cmbBirthSm.getItems().addAll("None","Single", "Twin1", "Twin2","Triplet1","Triplet2","Triplet3","Higher Order");
        cmbBirthSm.getSelectionModel().selectFirst();
        cmbBirthMOD.getItems().removeAll(cmbBirthMOD.getItems());
        cmbBirthMOD.getItems().addAll("None","Elective CS", "Emergency CS", "Forceps","Normal","Others","Vacuum");
        cmbBirthMOD.getSelectionModel().selectFirst();
        cmbBirthMD1.getItems().removeAll(cmbBirthMD1.getItems());
        cmbBirthMD1.getItems().addAll("None","No", "Not Known", "Yes");
        cmbBirthMD1.getSelectionModel().selectFirst();
        cmbBirthMD2.getItems().removeAll(cmbBirthMD2.getItems());
        cmbBirthMD2.getItems().addAll("None","Yes", "No");
        cmbBirthMD2.getSelectionModel().selectFirst();
        cmbBirthMDe1.getItems().removeAll(cmbBirthMDe1.getItems());
        cmbBirthMDe1.getItems().addAll("None","No", "Not Known", "Yes");
        cmbBirthMDe1.getSelectionModel().selectFirst();
        cmbBirthMDe2.getItems().removeAll(cmbBirthMDe2.getItems());
        cmbBirthMDe2.getItems().addAll("None","Non-Obstetric", "Obstetric");
        cmbBirthMDe2.getSelectionModel().selectFirst();
        cmbBirthCOD.getItems().removeAll(cmbBirthCOD.getItems());
        cmbBirthCOD.getItems().addAll("None","Asphyxia", "Congenital malformation", "Infection","Not established","Other","Rh isoimmunisation","Trauma");
        cmbBirthCOD.getSelectionModel().selectFirst();
        cmbBirthSB1.getItems().removeAll( cmbBirthSB1.getItems());
        cmbBirthSB1.getItems().addAll("None","Before Labor", "During Labor");
        cmbBirthSB1.getSelectionModel().selectFirst();
        cmbBirthSB2.getItems().removeAll( cmbBirthSB2.getItems());
        cmbBirthSB2.getItems().addAll("None","Fresh", "Macerated");
        cmbBirthSB2.getSelectionModel().selectFirst();
        cmbExtraLE.getItems().removeAll( cmbExtraLE.getItems());
        cmbExtraLE.getItems().addAll("None","Not Done", "Pass","Referred");
        cmbExtraLE.getSelectionModel().selectFirst();

        cmbExtraRE.getItems().removeAll( cmbExtraRE.getItems());
        cmbExtraRE.getItems().addAll("None","Not Done", "Pass","Referred");
        cmbExtraRE.getSelectionModel().selectFirst();



    }
    public class RandomString {

        // function to generate a random string of length n

        String getAlphaNumericString(int n) {

            // chose a Character random from this String
            String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                    + "0123456789"
                    + "abcdefghijklmnopqrstuvxyz";

            // create StringBuffer size of AlphaNumericString
            StringBuilder sb = new StringBuilder(n);

            for (int i = 0; i < n; i++) {

                // generate a random number between
                // 0 to AlphaNumericString variable length
                int index
                        = (int) (AlphaNumericString.length()
                        * Math.random());

                // add Character one by one in end of sb
                sb.append(AlphaNumericString
                        .charAt(index));
            }

            return sb.toString();
        }
    }

    @FXML
    private void saveIntraRecord() throws IOException {
        System.out.println("done");
        ArrayList<String> recordData = new ArrayList<>();

        // recording combo boxes

        RandomString rs = new RandomString();

        String eid = rs.getAlphaNumericString(7);
        recordData.add(eid);
        recordData.add(cmbIntraCCode.getValue().toString());
        recordData.add(cmbIntraHRB.getValue().toString());
        recordData.add(cmbIntraRead.getValue().toString());
        recordData.add(cmbIntraSex.getValue().toString());
        recordData.add(cmbIntraMod.getValue().toString());
        recordData.add(cmbIntraBaabb.getValue().toString());
        recordData.add(cmbIntraMBG.getValue().toString());
        recordData.add(cmbIntraBBG.getValue().toString());
        recordData.add(cmbIntraHS.getValue().toString());
        recordData.add(cmbIntraRR.getValue().toString());
        recordData.add(cmbIntraCCHD.getValue().toString());
        recordData.add(cmbIntraOAE.getValue().toString());
        recordData.add(cmbIntraSM.getValue().toString());
        recordData.add(cmbIntraMD1.getValue().toString());
        recordData.add(cmbIntraMD2.getValue().toString());
        recordData.add(cmbIntraMD3.getValue().toString());
        recordData.add(cmbIntraMD4.getValue().toString());
        recordData.add(cmbIntraMP.getValue().toString());
        recordData.add(cmbIntraMMi.getValue().toString());
        recordData.add(cmbIntraOutcome.getValue().toString());
        recordData.add(cmbIntraMD.getValue().toString());
        recordData.add(cmbIntraHC.getValue().toString());
        recordData.add(cmbIntraIGC.getValue().toString());

        // recording text fields

        recordData.add(txtIntraBRecordNo.getText());
        recordData.add(txtIntraMname.getText());
        recordData.add(txtIntraDOB.getText());
        recordData.add(txtIntraTOB.getText());
        recordData.add(txtIntraBW.getText());
        recordData.add(txtIntraGes.getText());
        recordData.add(txtIntraAp1.getText());
        recordData.add(txtIntraAp5.getText());
        recordData.add(txtIntraAp10.getText());
        recordData.add(txtIntraLSCS.getText());
        recordData.add(txtIntraFname.getText());
        recordData.add(txtIntraTel.getText());
        recordData.add(txtIntraDate1.getText());
        recordData.add(txtIntraDate2.getText());
        recordData.add(txtIntraDate3.getText());
        recordData.add(txtIntraMD1.getText());
        recordData.add(txtIntraMD2.getText());
        recordData.add(txtIntraMD3.getText());
        recordData.add(txtIntraMD4.getText());
        recordData.add(txtIntraMD5.getText());
        recordData.add(txtIntraMD6.getText());
        recordData.add(txtIntraOB.getText());
        recordData.add(txtIntraRD.getText());
        recordData.add(txtIntraTSH.getText());
        recordData.add(txtIntraTSHD.getText());
        recordData.add(txtIntraCNS.getText());
        recordData.add(txtIntraMP.getText());
        recordData.add(txtIntraMMa.getText());
        recordData.add(txtIntraMMi.getText());
        recordData.add(txtIntraTreat1.getText());
        recordData.add(txtIntraTreat2.getText());
        recordData.add(txtIntraTreat3.getText());
        recordData.add(txtIntraDOD.getText());
        recordData.add(txtIntraWAD.getText());
        recordData.add(txtIntraHC.getText());
        recordData.add(txtIntraDEB.getText());
        recordData.add(txtIntraSB.getText());
        recordData.add(txtIntraIAD.getText());
        recordData.add(txtIntraNNPD.getText());

        // Text area

        recordData.add(txtIntraAdd.getText());
        recordData.add(txtIntraDiag.getText());




        // READING CHECK BOXES


        if (chkIntraLD1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraLD2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraLD3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraLD4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraLD5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraLD6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraLD7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraOP1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP8.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP9.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP10.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP11.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraOP12.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraRD1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraRD2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraRD3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraRD4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraRD5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraND1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraND2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraND3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }



        if (chkIntraND5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraND6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraND7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraND8.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraCNS1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraCNS2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraCNS3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraCNS4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP8.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP9.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMP10.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMP11.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }




        if (chkIntraNC.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraAS.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMa1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMa2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMa3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMa4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMa5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMa6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMa7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraMMi1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi8.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi9.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi10.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi11.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi12.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraMMi13.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraTreat1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraTreat2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat8.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat9.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat10.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat11.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraTreat12.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }



        if (chkIntraSI1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkIntraSI2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        if (chkIntraSS.isSelected()) {
            recordData.add("True");


        } else {
            recordData.add("False");
        }
        if (chkIntraMMo.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }

        IntraMuralHelper helper = new IntraMuralHelper();
        helper.insertDatabase(recordData);



        
    }










        @FXML
        private void saveExtraRecord() throws IOException {
            System.out.println("done");

            ArrayList<String> recordData = new ArrayList<>();

            RandomString rs1 = new RandomString();

            String eid = rs1.getAlphaNumericString(6);
            recordData.add(eid);

            // recording combo boxes


            recordData.add(cmbExtraCCode.getValue().toString());
            recordData.add(cmbExtraHRB.getValue().toString());
            recordData.add(cmbExtraRead.getValue().toString());
            recordData.add(cmbExtraSex.getValue().toString());
            recordData.add(cmbExtraMod.getValue().toString());
            recordData.add(cmbExtraBaabb.getValue().toString());
            recordData.add(cmbExtraSM.getValue().toString());
            recordData.add(cmbExtraMBG.getValue().toString());
            recordData.add(cmbExtraBBG.getValue().toString());
            recordData.add(cmbExtraHS.getValue().toString());
            recordData.add(cmbExtraLE.getValue().toString());
            recordData.add(cmbExtraRE.getValue().toString());
            recordData.add(cmbExtraRR.getValue().toString());
            recordData.add(cmbExtraMD1.getValue().toString());
            recordData.add(cmbExtraMD3.getValue().toString());
            recordData.add(cmbExtraMD4.getValue().toString());
            recordData.add(cmbExtraMP.getValue().toString());
            recordData.add(cmbExtraBF.getValue().toString());
            recordData.add(cmbExtraMMi.getValue().toString());
            recordData.add(cmbExtraOutcome.getValue().toString());
            recordData.add(cmbExtraMD.getValue().toString());
            recordData.add(cmbExtraHC.getValue().toString());
            recordData.add(cmbExtraIGC.getValue().toString());

            // recording text fields

            recordData.add(txtExtraBRecordNo.getText());
            recordData.add(txtExtraMname.getText());
            recordData.add(txtExtraDOB.getText());
            recordData.add(txtExtraTOB.getText());
            recordData.add(txtExtraBW.getText());
            recordData.add(txtExtraGes.getText());
            recordData.add(txtExtraAp1.getText());
            recordData.add(txtExtraAp5.getText());
            recordData.add(txtExtraAp10.getText());
            recordData.add(txtExtraFname.getText());
            recordData.add(txtExtraTel.getText());
            recordData.add(txtExtraMD1.getText());
            recordData.add(txtExtraMD2.getText());
            recordData.add(txtExtraMD3.getText());
            recordData.add(txtExtraMD4.getText());
            recordData.add(txtExtraMD5.getText());
            recordData.add(txtExtraMD6.getText());
            recordData.add(txtExtraOP.getText());
            recordData.add(txtExtraRD.getText());
            recordData.add(txtExtraCNS.getText());
            recordData.add(txtExtraMP.getText());
            recordData.add(txtExtraMMa.getText());
            recordData.add(txtExtraMMi.getText());
            recordData.add(txtExtraTreat1.getText());
            recordData.add(txtExtraTreat2.getText());
            recordData.add(txtExtraTreat3.getText());
            recordData.add(txtExtraDOD.getText());
            recordData.add(txtExtraWAD.getText());
            recordData.add(txtExtraHC.getText());
            recordData.add(txtExtraDEB.getText());
            recordData.add(txtExtraSB.getText());
            recordData.add(txtExtraIAD.getText());
            recordData.add(txtExtraNNPD.getText());

            //  TEXT FIELD
            recordData.add(txtExtraAdd.getText());
            recordData.add(txtExtraDiag.getText());



            // READING CHECK BOXES

            if (chkExtraLD1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraLD2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraLD3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraLD4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraLD5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraLD6.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraLD7.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP6.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP7.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP8.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP9.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP10.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP11.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraOP12.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraRD1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraRD2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraRD3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraRD4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraRD5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraND1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraND2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraND3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraND4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraND5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraND6.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraND7.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraCNS1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraCNS2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraCNS3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraCNS4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }



            if (chkExtraMP1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP6.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP7.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP8.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP9.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMP10.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMP11.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraNC.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraAS.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMa1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMa2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMa3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMa4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMa5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMa6.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMa7.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraBF.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraMMi1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi6.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi7.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi8.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi9.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi10.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi11.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi12.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMi13.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraTreat1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraTreat2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat3.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat4.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat5.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat6.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat7.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat8.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat9.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat10.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat11.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraTreat12.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }



            if (chkExtraSI1.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraSI2.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }

            if (chkExtraSS.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }
            if (chkExtraMMo.isSelected()){
                recordData.add("True");
            }else{
                recordData.add("False");
            }


            ExtraMuralHelper helper = new ExtraMuralHelper();
            helper.insertDatabase(recordData);

        }


    @FXML
    private void saveBirthRecord() throws IOException {
        ArrayList<String> recordData = new ArrayList<>();
        RandomString rs2 = new RandomString();

        String eid = rs2.getAlphaNumericString(5);
        recordData.add(eid);

        // Reading Combo Boxes

        recordData.add(cmbBirthCcode.getValue().toString());
        recordData.add(cmbBirthSex.getValue().toString());
        recordData.add(cmbBirthSm.getValue().toString());
        recordData.add(cmbBirthMOD.getValue().toString());
        recordData.add(cmbBirthMD1.getValue().toString());
        recordData.add(cmbBirthMD2.getValue().toString());
        recordData.add(cmbBirthCOD.getValue().toString());
        recordData.add(cmbBirthMDe1.getValue().toString());
        recordData.add(cmbBirthMDe2.getValue().toString());
        recordData.add(cmbBirthSB1.getValue().toString());
        recordData.add(cmbBirthSB2.getValue().toString());


        // recording text fields
        recordData.add(txtBirthBHRN.getText());
        recordData.add(txtBirthNNPD.getText());
        recordData.add(txtBirthMname.getText());
        recordData.add(txtBirthDOB.getText());
        recordData.add(txtBirthTPfB.getText());
        recordData.add(txtBirthBW.getText());
        recordData.add(txtBirthGES.getText());
        recordData.add(txtBirthMD1.getText());
        recordData.add(txtBirthMD2.getText());
        recordData.add(txtBirthMD3.getText());
        recordData.add(txtBirthMD4.getText());
        recordData.add(txtBirthMD5.getText());
        recordData.add(txtBirthOP.getText());
        recordData.add(txtBirthMDe1.getText());
        recordData.add(txtBirthMDe2.getText());
        recordData.add(txtBirthMDe3.getText());
        recordData.add(txtBirthMP.getText());


        // READING CHECK BOXES
        if (chkBirthLabor1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthLabor2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthLabor3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthLabor4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthLabor5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP8.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP9.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP10.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP11.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthOP12.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthCOD1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthCOD2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthCOD3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthCOD4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthCOD5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthCOD6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthCOD7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP1.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP2.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP3.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP4.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP5.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP6.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP7.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP8.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP9.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP10.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        if (chkBirthMP11.isSelected()) {
            recordData.add("True");
        } else {
            recordData.add("False");
        }
        StillBirthHelper helper = new StillBirthHelper();
        helper.insertDatabase(recordData);
    }





    @FXML
    private void printIntra() throws IOException{
        try{


            ArrayList<String> DATA = new ArrayList<>();


            // Class.forName("com.mysql.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/aiimsbbs","root","1234asdf");



            String query = "SELECT * FROM intramurallivebirths";


            //here sonoo is database name, root is username and password

            Statement stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery(query);


            if(rs.next()) {
                String entryid = rs.getString("entryid");
                String CenterCode = rs.getString("CenterCode");
                String Highriskbaby = rs.getString("Highriskbaby");
                String Readmission = rs.getString("Readmission");
                String Sex = rs.getString("Sex");
                String ModeofDelivery = rs.getString("ModeofDelivery");
                String Babyattendedatbirthby = rs.getString("Babyattendedatbirthby");
                String MotherBloodGroup = rs.getString("MotherBloodGroup");
                String BabyBloodGroup = rs.getString("BabyBloodGroup");
                String HearingScreening = rs.getString("HearingScreening");
                String RedReflex = rs.getString("RedReflex");
                String CCHDScreening = rs.getString("CCHDScreening");
                String OAE = rs.getString("OAE");
                String SingleMultiple = rs.getString("SingleMultiple");
                String Unit = rs.getString("Unit");
                String ConsultantName = rs.getString("ConsultantName");
                String PreviousIUGR = rs.getString("PreviousIUGR");
                String AntenatalCare = rs.getString("AntenatalCare");
                String Booked = rs.getString("Booked");
                String ROP = rs.getString("ROP");
                String Outcome = rs.getString("Outcome");
                String MaternalDeath = rs.getString("MaternalDeath");
                String HospitalCourse = rs.getString("HospitalCourse");
                String Intraauterinegrowthcategory = rs.getString("Intraauterinegrowthcategory");
                String BabyHospitalRecordNumber = rs.getString("BabyHospitalRecordNumber");
                String MotherName = rs.getString("MotherName");
                String DateofBirth = rs.getString("DateofBirth");
                String TimeofBirth = rs.getString("TimeofBirth");
                String BirthWeight = rs.getString("BirthWeight");
                String Gestation = rs.getString("Gestation");
                String Apgar1min = rs.getString("Apgar1min");
                String Apgar5min = rs.getString("Apgar5min");
                String Apgar10min = rs.getString("Apgar10min");
                String IndicationofLSCS = rs.getString("IndicationofLSCS");
                String Fathername = rs.getString("Fathername");
                String telnumber = rs.getString("telnumber");
                String DateRedreflex = rs.getString("DateRedreflex");
                String DateCCHDscreening = rs.getString("DateCCHDscreening");
                String DateOAE = rs.getString("DateOAE");
                String MotherCrno = rs.getString("MotherCrno");
                String Maternalage = rs.getString("Maternalage");
                String Gravida = rs.getString("Gravida");
                String Para = rs.getString("Para");
                String Abortion = rs.getString("Abortion");
                String Stillbirth = rs.getString("Stillbirth");
                String OthersObstetricproblems = rs.getString("OthersObstetricproblems");
                String OthersRespiratoryproblems = rs.getString("OthersRespiratoryproblems");
                String SerumTSH = rs.getString("SerumTSH");
                String DateResuscitation = rs.getString("DateResuscitation");
                String OthersCNSdisorders = rs.getString("OthersCNSdisorders");
                String OthersMedicalproblems = rs.getString("OthersMedicalproblems");
                String OthersMajormalformations = rs.getString("OthersMajormalformations");
                String OthersMisc_morbidity = rs.getString("OthersMisc_morbidity");
                String DurationOxygen = rs.getString("DurationOxygen");
                String DurationCPAP = rs.getString("DurationCPAP");
                String DurationIMV = rs.getString("DurationIMV");
                String DateofDischarge = rs.getString("DateofDischarge");
                String WeightatDischarge = rs.getString("WeightatDischarge");
                String Headcircumference = rs.getString("Headcircumference");
                String Dataenteredby = rs.getString("Dataenteredby");
                String Supervisedby = rs.getString("Supervisedby");
                String Icterusatdischarge = rs.getString("Icterusatdischarge");
                String NNPDnumber = rs.getString("NNPDnumber");
                String Address = rs.getString("Address");
                String Diagnosis = rs.getString("Diagnosis");
                String Nonvertexpresentation = rs.getString("Nonvertexpresentation");
                String Oxytocinuse = rs.getString("Oxytocinuse");
                String ProlongedROM18h = rs.getString("ProlongedROM18h");
                String Meconiumstainedliqour = rs.getString("Meconiumstainedliqour");
                String Foulamellingliquor = rs.getString("Foulamellingliquor");
                String Fetalbradycardia120 = rs.getString("Fetalbradycardia120");
                String Fetaltachycardia160 = rs.getString("Fetaltachycardia160");
                String SevereaanemiaHb7gdl = rs.getString("SevereaanemiaHb7gdl");
                String Pregnancyinducedhypertension = rs.getString("Pregnancyinducedhypertension");
                String Preeclamptictoxemia = rs.getString("Preeclamptictoxemia");
                String Eclampsia = rs.getString("Eclampsia");
                String Gestationaldiabetes = rs.getString("Gestationaldiabetes");
                String Oligohydramnios = rs.getString("Oligohydramnios");
                String Polyhydramnios = rs.getString("Polyhydramnios");
                String Cephalopelvicdisproprotion = rs.getString("Cephalopelvicdisproprotion");
                String Previouscaesereamdelivery = rs.getString("Previouscaesereamdelivery");
                String antepartumhemorrhage = rs.getString("antepartumhemorrhage");
                String placentaprevia = rs.getString("placentaprevia");
                String abruptioplacentae = rs.getString("abruptioplacentae");
                String Transienttachypneadelayedadapt = rs.getString("Transienttachypneadelayedadapt");
                String Pneumonia = rs.getString("Pneumonia");
                String Meconiumaspiration = rs.getString("Meconiumaspiration");
                String Hyalinemembranedisease = rs.getString("Hyalinemembranedisease");
                String Pneumothorax = rs.getString("Pneumothorax");
                String Oxygenresuscitation = rs.getString("Oxygenresuscitation");
                String Bagandmask = rs.getString("Bagandmask");
                String Chestcompression = rs.getString("Chestcompression");
                String Intubationformeconium = rs.getString("Intubationformeconium");
                String Intubationotherwise = rs.getString("Intubationotherwise");
                String Adrenaline = rs.getString("Adrenaline");
                String Volumeexpanders = rs.getString("Volumeexpanders");
                String Hypoxicischemicencephalopathy = rs.getString("Hypoxicischemicencephalopathy");
                String Seizures = rs.getString("Seizures");
                String IVH = rs.getString("IVH");
                String Othersintracranialbleed = rs.getString("Othersintracranialbleed");
                String DiabetesotherthanGDM = rs.getString("DiabetesotherthanGDM");
                String Heartdisease = rs.getString("Heartdisease");
                String Renaldisease = rs.getString("Renaldisease");
                String Hypertension = rs.getString("Hypertension");
                String Seizuredisorder = rs.getString("Seizuredisorder");
                String Tuberculosis = rs.getString("Tuberculosis");
                String Malaria = rs.getString("Malaria");
                String Asthma = rs.getString("Asthma");
                String HepatitisB = rs.getString("HepatitisB");
                String Syphilis = rs.getString("Syphilis");
                String HIVinfection = rs.getString("HIVinfection");
                String ReceivedNurseryCare12hr = rs.getString("ReceivedNurseryCare12hr");
                String Antenatalsteroids = rs.getString("Antenatalsteroids");
                String Cardiacmalformation = rs.getString("Cardiacmalformation");
                String Hydrocephalus = rs.getString("Hydrocephalus");
                String Neuraltubeeffect = rs.getString("Neuraltubeeffect");
                String Cleftlipplate = rs.getString("Cleftlipplate");
                String Gestrointestinalmalformation = rs.getString("Gestrointestinalmalformation");
                String Genitourinarymalformation = rs.getString("Genitourinarymalformation");
                String Rhisoimmunisation = rs.getString("Rhisoimmunisation");
                String Hypothermia = rs.getString("Hypothermia");
                String Apneicspell = rs.getString("Apneicspell");
                String Hypoglycemia = rs.getString("Hypoglycemia");
                String Hypocalcemia = rs.getString("Hypocalcemia");
                String Anemia = rs.getString("Anemia");
                String NEC = rs.getString("NEC");
                String PDA = rs.getString("PDA");
                String VitaminKdeficiencybleeding = rs.getString("VitaminKdeficiencybleeding");
                String Neonatalcholestasis = rs.getString("Neonatalcholestasis");
                String Majorbirthtrauma = rs.getString("Majorbirthtrauma");
                String CLD = rs.getString("CLD");
                String INfluids = rs.getString("INfluids");
                String Antibiotic = rs.getString("Antibiotic");
                String OxygenTreatment = rs.getString("OxygenTreatment");
                String CPAP = rs.getString("CPAP");
                String IMV = rs.getString("IMV");
                String Surfactant = rs.getString("Surfactant");
                String Bloodplasmatransfusion = rs.getString("Bloodplasmatransfusion");
                String Phototherapy = rs.getString("Phototherapy");
                String Exchangetransfusion = rs.getString("Exchangetransfusion");
                String Parenteralnutrition = rs.getString("Parenteralnutrition");
                String LaserforROP = rs.getString("LaserforROP");
                String Anyothersurgery = rs.getString("Anyothersurgery");
                String Septicemiapneumoniameningitis = rs.getString("Septicemiapneumoniameningitis");
                String Tetanusneonatorum = rs.getString("Tetanusneonatorum");
                String SystemicSepsis = rs.getString("SystemicSepsis");
                String Misc_Morbidity = rs.getString("Misc_Morbidity");

            }




            int i=1;
            while(i<149)
            {

                DATA.add(rs.getString(i) );
                i++;

            }

            PDDocument document = new PDDocument();

            for (int j = 0; j < 1; j++) {
                //Creating a blank page
                PDPage blankPage = new PDPage();

                //Adding the blank page to the document
                document.addPage(blankPage);
            }

            //Saving the document

            document.save("C:/pdf/my_doc2.pdf");



            PDPage pageint = document.getPage(0);
            PDPageContentStream contentStreamint = new PDPageContentStream(document, pageint);//this for intra
            contentStreamint.beginText();

            contentStreamint.setFont(PDType1Font.TIMES_ROMAN, 14);
            contentStreamint.newLineAtOffset(180, 770 );
            String textint="DEPARTMENT OF NEONATOLOGY";
            contentStreamint.showText(textint);

            contentStreamint.newLineAtOffset(-70, -15 );
            String textint1="ALL INDIA INSTITUTE OF MEDICAL SCIENCE, BHUBANESWAR-19 ";
            contentStreamint.showText(textint1);

            contentStreamint.newLineAtOffset(70, -15 );
            String textint2="DISCHARGE SUMMERY (Inborn) ";
            contentStreamint.showText(textint2);

            contentStreamint.setFont(PDType1Font.TIMES_ROMAN, 12);
            contentStreamint.newLineAtOffset(-150, -20 );
            String textint3="Baby's IP No:  ";
            contentStreamint.showText(textint3);
            String textint4=DATA.get(24);
            contentStreamint.showText(textint4);

            contentStreamint.newLineAtOffset(200, 0 );
            String textint5="NNPD Number:  ";
            contentStreamint.showText(textint5);
            String textint6=DATA.get(62);
            contentStreamint.showText(textint6);

            contentStreamint.newLineAtOffset(200, 0 );
            String textint7="Mother No.:  ";
            contentStreamint.showText(textint7);
            String textint8=DATA.get(39);
            contentStreamint.showText(textint8);

            contentStreamint.newLineAtOffset(-400, -15 );
            String textint9="Mother's Name   Mrs ";
            contentStreamint.showText(textint9);
            String textint10=DATA.get(25);
            contentStreamint.showText(textint10);

            contentStreamint.newLineAtOffset(250, 0 );
            String textint11="Father's Name  Mr ";
            contentStreamint.showText(textint11);
            String textint12=DATA.get(34);
            contentStreamint.showText(textint12);

            contentStreamint.newLineAtOffset(250, 0 );
            String textint13="Unit: ";
            contentStreamint.showText(textint13);
            String textint14=DATA.get(14);
            contentStreamint.showText(textint14);

            contentStreamint.newLineAtOffset(-500, -15 );
            String textint15="Address:  ";
            contentStreamint.showText(textint15);
            String textint16= DATA.get(63);
            contentStreamint.showText(textint16);

            contentStreamint.newLineAtOffset(0, -15 );
            String textint17="Mobile Number:  ";
            contentStreamint.showText(textint17);
            String textint18=DATA.get(35);
            contentStreamint.showText(textint18);

            contentStreamint.newLineAtOffset(300, 0 );
            String textint19="OG Consultant Name:  ";
            contentStreamint.showText(textint19);
            String textint20=DATA.get(15);
            contentStreamint.showText(textint20);

            contentStreamint.newLineAtOffset(-300, -20 );
            String textint21="Date of Birth:  ";
            contentStreamint.showText(textint21);
            String textint22=DATA.get(26);
            contentStreamint.showText(textint22);

            contentStreamint.newLineAtOffset(150, 0 );
            String textint23="Time of Birth(24hr):  ";
            contentStreamint.showText(textint23);
            String textint24=DATA.get(27);
            contentStreamint.showText(textint24);

            contentStreamint.newLineAtOffset(200, 0 );
            String textint25="Gender:  ";
            contentStreamint.showText(textint25);
            String textint26=DATA.get(4);
            contentStreamint.showText(textint26);

            contentStreamint.newLineAtOffset(100, 0 );
            String textint27="Birth weight(gm):  ";
            contentStreamint.showText(textint27);
            String textint28=DATA.get(28);
            contentStreamint.showText(textint28);

            contentStreamint.newLineAtOffset(-450, -15 );
            String textint29="Gestation(best estimate):  ";
            contentStreamint.showText(textint29);
            String textint30=DATA.get(29);
            contentStreamint.showText(textint30);

            contentStreamint.newLineAtOffset(150, 0 );
            String textint31="Mode of delivery:  ";
            contentStreamint.showText(textint31);
            String textint32=DATA.get(5);
            contentStreamint.showText(textint32);

            contentStreamint.newLineAtOffset(160, 0 );
            String textint33="Intrauterine growth category:  ";
            contentStreamint.showText(textint33);
            String textint34=DATA.get(23);
            contentStreamint.showText(textint34);

            contentStreamint.newLineAtOffset(-310, -15 );
            String textint35="IndicationofLSCS:  ";
            contentStreamint.showText(textint35);
            String textint36=DATA.get(33);
            contentStreamint.showText(textint36);

            contentStreamint.newLineAtOffset(0, -20 );
            String textint37="NEONATAL DETAILS";
            contentStreamint.showText(textint37);

            contentStreamint.newLineAtOffset(0, -15 );
            String textint38="Apgar 1 min:  ";
            contentStreamint.showText(textint38);
            String textint39=DATA.get(30);
            contentStreamint.showText(textint39);

            contentStreamint.newLineAtOffset(150, 0 );
            String textint40="Apgar 5 min:  ";
            contentStreamint.showText(textint40);
            String textint41=DATA.get(31);
            contentStreamint.showText(textint41);

            contentStreamint.newLineAtOffset(-150, -15 );
            String textint42="Apgar 10 min:  ";
            contentStreamint.showText(textint42);
            String textint43=DATA.get(32);
            contentStreamint.showText(textint43);

            contentStreamint.newLineAtOffset(270, 30 );
            String textint44=" RESUSCITATION REQUIRED ";
            contentStreamint.showText(textint44);

            contentStreamint.newLineAtOffset(170, 0 );
            if("True".equals(DATA.get(90)))
            {
                String textint45=" Oxygen ";
                contentStreamint.showText(textint45);
            }

            contentStreamint.newLineAtOffset(-170, -15 );
            if("True".equals(DATA.get(91)))
            {
                String textint46=" Bag and Mask ";
                contentStreamint.showText(textint46);
            }

            contentStreamint.newLineAtOffset(75, 0 );
            if("True".equals(DATA.get(92)))
            {
                String textint47=" Chest compression ";
                contentStreamint.showText(textint47);
            }

            contentStreamint.newLineAtOffset(95, 0 );
            if("True".equals(DATA.get(93)))
            {
                String textint48=" Intubation foe meconium ";
                contentStreamint.showText(textint48);
            }

            contentStreamint.newLineAtOffset(-170, -15 );
            if("True".equals(DATA.get(94)))
            {
                String textint49=" Intubation otherwise ";
                contentStreamint.showText(textint49);
            }

            contentStreamint.newLineAtOffset(120, 0 );
            if("True".equals(DATA.get(95)))
            {
                String textint50="Adernaline ";
                contentStreamint.showText(textint50);
            }

            contentStreamint.newLineAtOffset(70, 0 );
            if("True".equals(DATA.get(96)))
            {
                String textint51=" Volume expanders";
                contentStreamint.showText(textint51);
            }

            contentStreamint.newLineAtOffset(-465, -20 );
            String textint52=" DIAGNOSIS: ";
            contentStreamint.showText(textint52);

            contentStreamint.newLineAtOffset(100, 0 );
            String textint53=DATA.get(13);
            contentStreamint.showText(textint53);

            contentStreamint.newLineAtOffset(70, 0 );
            String textint54=DATA.get(4);
            contentStreamint.showText(textint54);

            int b= Integer.parseInt(DATA.get(29));
            if(b<=37)
            {
                contentStreamint.newLineAtOffset(70, 0);
                String textint55 = "Preterm";
                contentStreamint.showText(textint55);
            }
            if(b<42&&b>37)
            {
                contentStreamint.newLineAtOffset(70, 0);
                String textint55 = "Fullterm";
                contentStreamint.showText(textint55);
            }
            if(b>=42)
            {
                contentStreamint.newLineAtOffset(70, 0);
                String textint55 = "Postterm";
                contentStreamint.showText(textint55);
            }

            contentStreamint.newLineAtOffset(70, 0 );
            String textint56=DATA.get(23);
            contentStreamint.showText(textint56);

            contentStreamint.newLineAtOffset(130, 0 );
            String textint57=DATA.get(5);
            contentStreamint.showText(textint57);

            contentStreamint.newLineAtOffset(-410, -15 );

            int c= Integer.parseInt(DATA.get(28));
            if(c>=4000)
            {
                contentStreamint.newLineAtOffset(70, 0);
                String textint59 = "High Birth Weight";
                contentStreamint.showText(textint59);
            }
            if(c<=2500)
            {
                contentStreamint.newLineAtOffset(70, 0);
                String textint59 = "Low Birth weight";
                contentStreamint.showText(textint59);
            }
            if(c<4000&&c>2500)
            {
                contentStreamint.newLineAtOffset(70, 0);
                String textint59 = "Normal Birth Weight";
                contentStreamint.showText(textint59);
            }
            contentStreamint.newLineAtOffset(150, 0);
            String textint60 = DATA.get(18);
            contentStreamint.showText(textint60);

            contentStreamint.newLineAtOffset(-250, -20);
            String textint61 = "MORBIDITIES";
            contentStreamint.showText(textint61);

            contentStreamint.newLineAtOffset(0, -15);
            String textint62 = "Received Nursery Care >12hr: ";
            contentStreamint.showText(textint62);
            String textint63 = DATA.get(112);
            contentStreamint.showText(textint63);

            contentStreamint.newLineAtOffset(0, -15);
            String textint64 = "Respiratory Distress: ";
            contentStreamint.showText(textint64);
            contentStreamint.newLineAtOffset(150, 0);
            if("True".equals(DATA.get(85)))
            {
                String textint65=" Transient tachypnea ";
                contentStreamint.showText(textint65);
            }
            contentStreamint.newLineAtOffset(150, 0);
            if("True".equals(DATA.get(86)))
            {

                String textint66=" Pneumonnia ";
                contentStreamint.showText(textint66);
            }
            contentStreamint.newLineAtOffset(150, 0);
            if("True".equals(DATA.get(87)))
            {

                String textint67=" Meconium aspiration ";
                contentStreamint.showText(textint67);
            }
            contentStreamint.newLineAtOffset(-300, -15);
            if("True".equals(DATA.get(88)))
            {

                String textint68=" Hyaline membrane disease ";
                contentStreamint.showText(textint68);
            }
            contentStreamint.newLineAtOffset(150, 0);
            if("True".equals(DATA.get(89)))
            {
                String textint69=" Pneumothorax ";
                contentStreamint.showText(textint69);
            }

            contentStreamint.newLineAtOffset(-305, -15);
            String textint70=" Systematic Infection : ";
            contentStreamint.showText(textint70);

            contentStreamint.newLineAtOffset(150, 0);
            if("True".equals(DATA.get(145)))
            {
                String textint71=" Septicemia/ Pneumonia/meningitis ";
                contentStreamint.showText(textint71);
            }
            contentStreamint.newLineAtOffset(200, 0);
            if("True".equals(DATA.get(146)))
            {
                String textint72=" Tetanus neonatorum ";
                contentStreamint.showText(textint72);
            }

            contentStreamint.newLineAtOffset(-350, -15);
            String textint73=" Hyperbilirubinemia (Need for Phototherapy): ";
            contentStreamint.showText(textint73);

            if("False".equals(DATA.get(147)))
            {
                contentStreamint.newLineAtOffset(300, 0);
                String textint74="No";
                contentStreamint.showText(textint74);
            }
            if("True".equals(DATA.get(147)))
            {
                contentStreamint.newLineAtOffset(300, 0);
                String textint75="Yes";
                contentStreamint.showText(textint75);
            }

            contentStreamint.newLineAtOffset(-300, -15);
            String textint76=" Other Morbidity: ";
            contentStreamint.showText(textint76);

            contentStreamint.newLineAtOffset(100, 0);
            if("True".equals(DATA.get(120)))
            {
                String textint77="Rh isoimmunisation";
                contentStreamint.showText(textint77);
            }

            contentStreamint.newLineAtOffset(110, 0);
            if("True".equals(DATA.get(121)))
            {
                String textint78="Htothermia";
                contentStreamint.showText(textint78);
            }

            contentStreamint.newLineAtOffset(65, 0);
            if("True".equals(DATA.get(122)))
            {
                String textint79="Apenic spell";
                contentStreamint.showText(textint79);
            }

            contentStreamint.newLineAtOffset(70, 0);
            if("True".equals(DATA.get(123)))
            {
                String textint80="Hypoglycemia";
                contentStreamint.showText(textint80);
            }

            contentStreamint.newLineAtOffset(80, 0);
            if("True".equals(DATA.get(124)))
            {
                String textint81="Hypocalcemia";
                contentStreamint.showText(textint81);
            }

            contentStreamint.newLineAtOffset(80, 0);
            if("True".equals(DATA.get(125)))
            {
                String textint82="Anemia";
                contentStreamint.showText(textint82);
            }

            contentStreamint.newLineAtOffset(-405, -15);
            if("True".equals(DATA.get(126)))
            {
                String textint83="Polycythemia";
                contentStreamint.showText(textint83);
            }

            contentStreamint.newLineAtOffset(80, 0);
            if("True".equals(DATA.get(127)))
            {
                String textint84="NEC";
                contentStreamint.showText(textint84);
            }

            contentStreamint.newLineAtOffset(50, 0);

            String textint85=DATA.get(19);
            contentStreamint.showText(textint85);


            contentStreamint.newLineAtOffset(90, 0);
            if("True".equals(DATA.get(128)))
            {
                String textint86="PDA";
                contentStreamint.showText(textint86);
            }

            contentStreamint.newLineAtOffset(50, 0);
            if("True".equals(DATA.get(129)))
            {
                String textint87="Vitamin k deficiency bleeding";
                contentStreamint.showText(textint87);
            }

            contentStreamint.newLineAtOffset(-270, -15);
            if("True".equals(DATA.get(130)))
            {
                String textint88="Neonatal cholestasis";
                contentStreamint.showText(textint88);
            }

            contentStreamint.newLineAtOffset(150, 0);
            if("True".equals(DATA.get(131)))
            {
                String textint89="Major Birth trauma";
                contentStreamint.showText(textint89);
            }

            contentStreamint.newLineAtOffset(150, 0);
            if("True".equals(DATA.get(132)))
            {
                String textint90="CLD";
                contentStreamint.showText(textint90);
            }

            contentStreamint.newLineAtOffset(-400, -20);
            String textint91="Investigation: ";
            contentStreamint.showText(textint91);

            contentStreamint.newLineAtOffset(75, 0);
            String textint92="Mother's blood group: ";
            contentStreamint.showText(textint92);
            String textint93=DATA.get(7);
            contentStreamint.showText(textint93);

            contentStreamint.newLineAtOffset(170, 0);
            String textint94="Baby blood group: ";
            contentStreamint.showText(textint94);
            String textint95=DATA.get(8);
            contentStreamint.showText(textint95);

            contentStreamint.newLineAtOffset(150, 0);
            String textint96="CCHD Screening: ";
            contentStreamint.showText(textint96);
            String textint97=DATA.get(11);
            contentStreamint.showText(textint97);

            contentStreamint.newLineAtOffset(130, 0);
            String textint98=DATA.get(37);
            contentStreamint.showText(textint98);

            contentStreamint.newLineAtOffset(-525, -15);
            String textint99="Serum TSH: ";
            contentStreamint.showText(textint99);
            String textint100=DATA.get(47);
            contentStreamint.showText(textint100);
            contentStreamint.newLineAtOffset(110, 0);
            String textint101="microU/ml";
            contentStreamint.showText(textint101);
            contentStreamint.newLineAtOffset(55, 0);
            String textint102=DATA.get(48);
            contentStreamint.showText(textint102);

            contentStreamint.newLineAtOffset(70, 0);
            String textint103="OAE: ";
            contentStreamint.showText(textint103);
            String textint104=DATA.get(12);
            contentStreamint.showText(textint104);
            contentStreamint.newLineAtOffset(55, 0);
            String textint105=DATA.get(38);
            contentStreamint.showText(textint105);

            contentStreamint.newLineAtOffset(70, 0);
            String textint106="Red Reflex: ";
            contentStreamint.showText(textint106);
            String textint107=DATA.get(10);
            contentStreamint.showText(textint107);
            contentStreamint.newLineAtOffset(130, 0);
            String textint108=DATA.get(36);
            contentStreamint.showText(textint108);

            contentStreamint.newLineAtOffset(-490, -20);
            String textint109="Hospital course: ";
            contentStreamint.showText(textint109);
            String textint110=DATA.get(22);
            contentStreamint.showText(textint110);

            contentStreamint.newLineAtOffset(0, -35);
            String textint111="Date of Discharge ";
            contentStreamint.showText(textint111);

            contentStreamint.newLineAtOffset(150, 0);
            String textint112="Weight at Discharge(g)";
            contentStreamint.showText(textint112);

            contentStreamint.newLineAtOffset(150, 0);
            String textint113="Head Circumference(cm)";
            contentStreamint.showText(textint113);

            contentStreamint.newLineAtOffset(150, 0);
            String textint114="Icterus at discharge(mg/dl)";
            contentStreamint.showText(textint114);

            contentStreamint.newLineAtOffset(-450, -15);
            String textint115=DATA.get(56);
            contentStreamint.showText(textint115);

            contentStreamint.newLineAtOffset(150, 0);
            String textint116=DATA.get(57);
            contentStreamint.showText(textint116);

            contentStreamint.newLineAtOffset(150, 0);
            String textint117=DATA.get(58);
            contentStreamint.showText(textint117);

            contentStreamint.newLineAtOffset(150, 0);
            String textint118=DATA.get(61);
            contentStreamint.showText(textint118);

            contentStreamint.newLineAtOffset(-450, -20);
            String textint119="Immunization schedule";
            contentStreamint.showText(textint119);

            contentStreamint.newLineAtOffset(0, -15);
            String textint120="BCG : at birth";
            contentStreamint.showText(textint120);

            contentStreamint.newLineAtOffset(0, -15);
            String textint121="OPV: at birth 6,10,14 weeks, then 18 months, 5 yrs";
            contentStreamint.showText(textint121);

            contentStreamint.newLineAtOffset(0, -15);
            String textint122="Hepatitis B: at birth 6,10,14 weeks";
            contentStreamint.showText(textint122);

            contentStreamint.newLineAtOffset(0, -15);
            String textint123="DPT: at 6,10,14 weeks then 18 months, 5 yrs";
            contentStreamint.showText(textint123);

            contentStreamint.newLineAtOffset(0, -15);
            String textint124="Measles, Rubella, JE, Vit A: 9 months";
            contentStreamint.showText(textint124);

            contentStreamint.newLineAtOffset(300, 75);
            String textint125="Danger signs";
            contentStreamint.showText(textint125);

            contentStreamint.newLineAtOffset(0, -15);
            String textint126="1. Poor feeding";
            contentStreamint.showText(textint126);

            contentStreamint.newLineAtOffset(0, -10);
            String textint127="2. Lethargy";
            contentStreamint.showText(textint127);

            contentStreamint.newLineAtOffset(0, -10);
            String textint128="3. Fast/ difficult breathing";
            contentStreamint.showText(textint128);

            contentStreamint.newLineAtOffset(0, -10);
            String textint129="4. Palms/ soles look yellow";
            contentStreamint.showText(textint129);

            contentStreamint.newLineAtOffset(0, -10);
            String textint130="5. Baby apperas blue";
            contentStreamint.showText(textint130);

            contentStreamint.newLineAtOffset(0, -10);
            String textint131="6. Abnormal movements/ fits";
            contentStreamint.showText(textint131);

            contentStreamint.newLineAtOffset(0, -10);
            String textint132="7. Temperature >37.5 deg C";
            contentStreamint.showText(textint132);

            contentStreamint.newLineAtOffset(-300, -15);
            String textint133="Advice at discharge";
            contentStreamint.showText(textint133);

            contentStreamint.newLineAtOffset(0, -15);
            String textint134="1. Exclusive breastmilk feeding for six months (NO BOTTLE)";
            contentStreamint.showText(textint134);

            contentStreamint.newLineAtOffset(0, -13);
            String textint135="2. Vitamin D3(400 IU/ ml): 1 ml once daily till 1 year of age";
            contentStreamint.showText(textint135);

            contentStreamint.newLineAtOffset(0, -13);
            String textint136="3. Iron drop (elemental iron - 25 mg/ml): 0.5 ml once daily after six months";
            contentStreamint.showText(textint136);

            contentStreamint.newLineAtOffset(0, -13);
            String textint137="4. Immunization as per schedule";
            contentStreamint.showText(textint137);

            contentStreamint.newLineAtOffset(0, -13);
            String textint138="5. Attend Neonatology OPD at 8:30 AM (Room no. 35) after 3 days";
            contentStreamint.showText(textint138);

            contentStreamint.newLineAtOffset(0, -15);
            String textint139="Follow up:";
            contentStreamint.showText(textint139);

            contentStreamint.newLineAtOffset(0, -13);
            String textint140="1. Attend High Risk Follow-up Clinic at Neonatology OPD (Room mo. 35) on Tuesday at 2 PM, if advised";
            contentStreamint.showText(textint140);

            contentStreamint.newLineAtOffset(0, -13);
            String textint141="2. If presence of danger signs, attend nearest Hospital / Pedlatrlclan / Casualty, AIIMS, BBSR";
            contentStreamint.showText(textint141);


            contentStreamint.newLineAtOffset(50, -40);
            String textint142="Senior Resident";
            contentStreamint.showText(textint142);

            contentStreamint.newLineAtOffset(350, 0);
            String textint143="Junior Resident";
            contentStreamint.showText(textint143);


            contentStreamint.endText();

            contentStreamint.moveTo(30, 735);
            contentStreamint.lineTo(580, 735);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 730);
            contentStreamint.lineTo(600, 730);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 730);
            contentStreamint.lineTo(10, 670);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 730);
            contentStreamint.lineTo(600, 670);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 670);
            contentStreamint.lineTo(600, 670);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 665);
            contentStreamint.lineTo(600, 665);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 665);
            contentStreamint.lineTo(10, 620);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 665);
            contentStreamint.lineTo(600, 620);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 620);
            contentStreamint.lineTo(600, 620);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 615);
            contentStreamint.lineTo(600, 615);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 615);
            contentStreamint.lineTo(10, 570);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 615);
            contentStreamint.lineTo(600, 570);
            contentStreamint.stroke();

            contentStreamint.moveTo(300, 615);
            contentStreamint.lineTo(300, 570);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 570);
            contentStreamint.lineTo(600, 570);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 565);
            contentStreamint.lineTo(600, 565);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 565);
            contentStreamint.lineTo(10, 535);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 565);
            contentStreamint.lineTo(600, 535);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 535);
            contentStreamint.lineTo(600, 535);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 530);
            contentStreamint.lineTo(600, 530);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 530);
            contentStreamint.lineTo(10, 395);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 530);
            contentStreamint.lineTo(600, 395);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 395);
            contentStreamint.lineTo(600, 395);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 390);
            contentStreamint.lineTo(600, 390);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 390);
            contentStreamint.lineTo(10, 360);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 390);
            contentStreamint.lineTo(600, 360);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 360);
            contentStreamint.lineTo(600, 360);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 355);
            contentStreamint.lineTo(600, 355);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 355);
            contentStreamint.lineTo(10, 325);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 355);
            contentStreamint.lineTo(600, 325);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 325);
            contentStreamint.lineTo(600, 325);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 320);
            contentStreamint.lineTo(600, 320);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 305);
            contentStreamint.lineTo(600, 305);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 320);
            contentStreamint.lineTo(10, 290);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 320);
            contentStreamint.lineTo(600, 290);
            contentStreamint.stroke();

            contentStreamint.moveTo(140, 320);
            contentStreamint.lineTo(140, 290);
            contentStreamint.stroke();

            contentStreamint.moveTo(290, 320);
            contentStreamint.lineTo(290, 290);
            contentStreamint.stroke();

            contentStreamint.moveTo(445, 320);
            contentStreamint.lineTo(445, 290);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 290);
            contentStreamint.lineTo(600, 290);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 285);
            contentStreamint.lineTo(600, 285);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 285);
            contentStreamint.lineTo(10, 195);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 285);
            contentStreamint.lineTo(600, 195);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 195);
            contentStreamint.lineTo(600, 195);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 180);
            contentStreamint.lineTo(600, 180);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 180);
            contentStreamint.lineTo(10, 115);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 180);
            contentStreamint.lineTo(600, 115);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 115);
            contentStreamint.lineTo(600, 115);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 100);
            contentStreamint.lineTo(600, 100);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 100);
            contentStreamint.lineTo(10, 75);
            contentStreamint.stroke();

            contentStreamint.moveTo(600, 100);
            contentStreamint.lineTo(600, 75);
            contentStreamint.stroke();

            contentStreamint.moveTo(10, 75);
            contentStreamint.lineTo(600, 75);
            contentStreamint.stroke();


            contentStreamint.close();

            document.save(new File("C:/pdf/my_doc2.pdf"));

            document.close();

            //Saving the document

            stmt.close();


        }
        catch(Exception e){ System.out.println(e);}

    }



}
