module AIIMSBBBSRPERINATALAPP {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires org.apache.pdfbox;
    requires jdk.compiler;
    requires jdk.jfr;

    opens com.spml.aiims.bbsr.model;

}